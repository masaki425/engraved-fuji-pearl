"""平らな版を Blender で組み立ててレンダリングする（painting-03/blender/build_blend.py をこの版で動かす）。

  /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup \\
      --python scripts/build_blend_flat.py -- [--profile flat_n02_s15] [--render] [--quick] [--video]
出力：scripts/engraved_fuji_pearl_flat_p1s_<ノズル>[_<大きさ>].blend、--render で renders_engraved_fuji_pearl_flat_p1s_…/
  （鏡・照明・カメラは painting-03 と同じ組み方。GPU 検出のためサンドボックスの外で実行する）
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
B03 = os.path.join(HERE, "build_blend.py")
sys.path.insert(0, HERE)
import design_flat as F  # noqa: E402

D = F.install()
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
key = args[args.index("--profile") + 1] if "--profile" in args else "flat_n02_s15"
p = dict(F.PROFILES[key])
_, nz, sz = key.split("_")
# build_blend.py は <NAME>_p1s_<NZ>.blend に書き出すので、NAME と NZ を分けて渡す
p.update(NAME="engraved_fuji_pearl_flat", NZ=nz + ("" if sz == "l" else f"_{sz}"))
D.PROFILES[key + "_blend"] = p
rest = [a for i, a in enumerate(args) if a != "--profile" and (i == 0 or args[i - 1] != "--profile")]
sys.argv = [sys.argv[0], "--", "--profile", key + "_blend"] + rest
g = {"__file__": B03, "__name__": "__main__"}
exec(compile(open(B03, encoding="utf-8").read(), B03, "exec"), g)
