"""スライス済み 3MF の G-code を読み、溝のある深さの層で「溝の間の面がちゃんと刷られるか」「溝がふさがらないか」を調べる。

設計（design.py）から、層の中央の高さでの断面（面のある所・溝の所）を、左右 1 mm おきの縦の線の上で作る。
G-code の押し出しの経路を線幅ぶんの太さ（カプセル）にして、同じ縦の線の上で重ねる。
  - 面の欠け：面の区間のうち、押し出しに覆われない割合。区間の半分以上が覆われない面を「欠けた面」と数える
  - 溝の埋まり：溝の区間のうち、押し出しに覆われた割合。開いている幅が 0.2 mm 未満になった溝を「ふさがった溝」と数える

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/print/check_lands.py <版 pair_raijin_n04 など> <スライス済み 3MF>
出力：標準出力と print/lands_report_<3MF の版名>.txt
"""
import math
import os
import re
import sys
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import design as D  # noqa: E402

DY = 0.01          # 縦の線の上の格子 [mm]
STEP_X = 1.0       # 縦の線の間隔 [mm]


def parse(gcode, zlo, zhi):
    """高さ zlo〜zhi の層の押し出しの線分 {層の中央の高さ: [x0, y0, x1, y1, 線幅]}。"""
    layers, cur = {}, None
    x = y = 0.0
    width, lh, ztop = 0.42, 0.12, 0.0
    num = re.compile(r"([XYZEIJ])(-?[\d.]+)")
    for line in gcode.splitlines():
        if line.startswith(";"):
            if line.startswith("; Z_HEIGHT:"):
                ztop = float(line.split(":")[1])
            elif line.startswith("; LAYER_HEIGHT:"):
                lh = float(line.split(":")[1])
                zm = round(ztop - lh / 2, 3) if ztop else None
            elif line.startswith("; LINE_WIDTH:"):
                width = float(line.split(":")[1])
            elif line.startswith("; CHANGE_LAYER"):
                cur = None
            continue
        if line[:3] not in ("G1 ", "G0 ", "G2 ", "G3 "):
            continue
        if cur is None and ztop:
            zm = round(ztop - lh / 2, 3)
            cur = layers.setdefault(zm, []) if zlo <= zm <= zhi else False
        a = dict(num.findall(line.split(";")[0]))
        nx, ny = float(a.get("X", x)), float(a.get("Y", y))
        e = float(a.get("E", 0))
        if cur is not False and cur is not None and e > 0:
            if line[:2] in ("G2", "G3") and "I" in a:
                cx, cy = x + float(a["I"]), y + float(a.get("J", 0))
                r = math.hypot(x - cx, y - cy)
                a0, a1 = math.atan2(y - cy, x - cx), math.atan2(ny - cy, nx - cx)
                if line[:2] == "G3" and a1 <= a0:
                    a1 += 2 * math.pi
                if line[:2] == "G2" and a1 >= a0:
                    a1 -= 2 * math.pi
                n = max(2, int(abs(a1 - a0) * r / 0.1))
                t = np.linspace(a0, a1, n + 1)
                px, py = cx + r * np.cos(t), cy + r * np.sin(t)
                for k in range(n):
                    cur.append((px[k], py[k], px[k + 1], py[k + 1], width))
            else:
                cur.append((x, y, nx, ny, width))
        x, y = nx, ny
    return {k: np.array(v) for k, v in layers.items() if v is not False and len(v)}


def covered(seg, c, ys):
    """縦の線 x = c の上で、線分の太さ（半径 = 線幅 / 2）に覆われる格子 ys の真偽。"""
    x0, y0, x1, y1, w = seg.T
    r = w / 2
    m = (np.minimum(x0, x1) - r <= c) & (np.maximum(x0, x1) + r >= c)
    x0, y0, x1, y1, r = x0[m], y0[m], x1[m], y1[m], r[m]
    lo = np.full(len(r), np.inf)
    hi = np.full(len(r), -np.inf)
    for px, py in ((x0, y0), (x1, y1)):                       # 端の円
        h2 = r ** 2 - (c - px) ** 2
        ok = h2 >= 0
        h = np.sqrt(np.maximum(h2, 0))
        lo = np.where(ok, np.minimum(lo, py - h), lo)
        hi = np.where(ok, np.maximum(hi, py + h), hi)
    dx, dy = x1 - x0, y1 - y0
    L = np.hypot(dx, dy) + 1e-12
    ux, uy = dx / L, dy / L
    # 帯：線分への垂直距離 <= r かつ 射影 t が 0〜L。x = c の上の y の区間の共通部分
    with np.errstate(divide="ignore", invalid="ignore"):
        # 垂直距離 |(-uy)(c - x0) + ux (y - y0)| <= r
        a1 = (-r + uy * (c - x0)) / ux + y0
        a2 = (r + uy * (c - x0)) / ux + y0
        b1 = (0 - ux * (c - x0)) / uy + y0
        b2 = (L - ux * (c - x0)) / uy + y0
    ilo = np.where(np.abs(ux) > 1e-9, np.minimum(a1, a2), -np.inf)
    ihi = np.where(np.abs(ux) > 1e-9, np.maximum(a1, a2), np.inf)
    ilo = np.where((np.abs(ux) <= 1e-9) & (np.abs(-uy * (c - x0)) > r), np.inf, ilo)
    tl = np.where(np.abs(uy) > 1e-9, np.minimum(b1, b2), np.where((ux * (c - x0) >= 0) & (ux * (c - x0) <= L), -np.inf, np.inf))
    th = np.where(np.abs(uy) > 1e-9, np.maximum(b1, b2), np.where((ux * (c - x0) >= 0) & (ux * (c - x0) <= L), np.inf, -np.inf))
    blo, bhi = np.maximum(ilo, tl), np.minimum(ihi, th)
    ok = (blo <= bhi) & (L > 1e-6)                            # 長さ 0 の押し出し（その場での戻しなど）は端の円だけ
    lo = np.where(ok, np.minimum(lo, blo), lo)
    hi = np.where(ok, np.maximum(hi, bhi), hi)
    good = lo <= hi
    lo, hi = lo[good], hi[good]
    d = np.zeros(len(ys) + 1)
    i0 = np.clip(np.searchsorted(ys, lo), 0, len(ys))
    i1 = np.clip(np.searchsorted(ys, hi, side="right"), 0, len(ys))
    np.add.at(d, i0, 1)
    np.add.at(d, i1, -1)
    return np.cumsum(d)[:-1] > 0


def main():
    prof, path = sys.argv[1], sys.argv[2]
    d = D.Design(D.PROFILES[prof])
    gcode = zipfile.ZipFile(path).read("Metadata/plate_1.gcode").decode()
    zb_max = float(d.Zb.max())
    layers = parse(gcode, zb_max + 0.02, d.Z0 + 0.3)
    # 板の中心：G-code の座標は、3MF の配置と少しずれることがある（P1S で y が 2 mm 小さかった）ので、
    # 溝より下の層の外周（外壁の線の中心の範囲）の中央から求める
    low = parse(gcode, 1.0, 1.3)
    s0 = low[min(low)]
    cx = (min(s0[:, 0].min(), s0[:, 2].min()) + max(s0[:, 0].max(), s0[:, 2].max())) / 2
    cy = (min(s0[:, 1].min(), s0[:, 3].min()) + max(s0[:, 1].max(), s0[:, 3].max())) / 2
    xs = np.arange(-d.W / 2 + 1, d.W / 2 - 1 + 1e-9, STEP_X)
    ys = np.arange(-d.HD, d.HD, DY)
    out = [f"{os.path.basename(path)}（{prof}）：溝の底の最も高い所 {zb_max:.2f} mm、縁 Z0 = {d.Z0:.2f} mm、縦の線 {len(xs)} 本、"
           f"G-code での板の中心 ({cx:.2f}, {cy:.2f})"]
    out.append("層の中央の高さ  面の数  欠けた面  面の覆われない割合  溝の数  ふさがった溝  溝の埋まった割合")
    worst = 0
    for zm in sorted(layers):
        seg = layers[zm].copy()
        seg[:, [0, 2]] -= cx
        seg[:, [1, 3]] -= cy
        n_land = miss_land = n_gr = closed = 0
        land_cells = land_miss = gr_cells = gr_fill = 0
        for c in xs:
            j = int(round((c + d.W / 2) / d.W * (d.NX - 1)))
            cov = covered(seg, c, ys)
            ylo, yhi, zlo, zhi = d.Ylo[:, j], d.Yhi[:, j], d.Zlo[:, j], d.Zhi[:, j]
            for i in range(d.N - 1):                              # 面 i：溝 i の奥の縁 〜 溝 i+1 の手前の縁
                if min(zhi[i], zlo[i + 1]) <= zm:
                    continue
                s = (ys >= yhi[i]) & (ys <= ylo[i + 1])
                k = s.sum()
                if k == 0:
                    continue
                miss = (~cov[s]).sum()
                n_land += 1
                land_cells += k
                land_miss += miss
                miss_land += miss > k / 2
            for i in range(d.N):                                  # 溝 i
                if d.Zb[i, j] >= zm:
                    continue
                s = (ys > ylo[i]) & (ys < yhi[i])
                k = s.sum()
                if k == 0:
                    continue
                f = cov[s]
                n_gr += 1
                gr_cells += k
                gr_fill += f.sum()
                closed += (k - f.sum()) * DY < 0.2
        if n_land == 0:
            continue
        worst = max(worst, miss_land, closed)
        out.append(f"{zm:8.3f} mm  {n_land:7d}  {miss_land:6d}  {land_miss / max(land_cells, 1) * 100:9.2f} %"
                   f"  {n_gr:7d}  {closed:6d}  {gr_fill / max(gr_cells, 1) * 100:9.2f} %")
    text = "\n".join(out)
    print(text)
    open(os.path.join(os.path.dirname(os.path.abspath(path)), "lands_report_" + os.path.basename(path)[:-len("_P1S.3mf")] + ".txt"), "w").write(text + "\n")


if __name__ == "__main__":
    main()
