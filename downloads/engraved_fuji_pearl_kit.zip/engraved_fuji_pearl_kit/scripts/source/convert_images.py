"""名画の画像を、正方形に切り抜いた RGB の配列 .npy（線形の色、上の行が絵の上）に変換する（Blender で実行）。
  /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup --python scripts/source/convert_images.py
"""
import os
import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N = 800
# (ファイル, 切り抜き [左, 下, 幅] を画像の幅に対する割合で)
JOBS = {
    "hokusai_red_fuji": ("hokusai_red_fuji.jpg", (0.333, 0.0, 0.667)),          # 富士の山頂を含む右側
    "vermeer_pearl_earring": ("vermeer_pearl_earring.jpg", (0.27, 0.31, 0.70)),  # 顔とターバン
}
for key, (fn, (cx, cy, cw)) in JOBS.items():
    img = bpy.data.images.load(os.path.join(HERE, fn))
    w, h = img.size
    px = np.empty(w * h * 4, np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)[..., :3]          # 行は下から上
    x0, y0, s = int(cx * w), int(cy * h), int(cw * w)
    s = min(s, w - x0, h - y0)
    crop = px[y0:y0 + s, x0:x0 + s]
    idx = (np.arange(N) + 0.5) * s / N
    ii = np.clip(idx.astype(int), 0, s - 1)
    small = crop[ii][:, ii]                     # 最近傍で N x N に縮小（後でぼかす）
    np.save(os.path.join(HERE, key + ".npy"), small[::-1].astype(np.float32))   # 行を上から下に
    print(key, w, h, "crop", x0, y0, s)
