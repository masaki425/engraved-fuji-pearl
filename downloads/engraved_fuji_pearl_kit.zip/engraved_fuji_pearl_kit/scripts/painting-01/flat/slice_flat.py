"""平らな版を Bambu Studio のコマンドラインで P1S 用にスライスする（painting-03/print/slice_p1s.py の設定をそのまま使う。サンドボックスの外で）。

  python3 painting-01/flat/slice_flat.py <版 ...> [--ams] [--project]
    版：flat_n04_l・flat_n04_s15・flat_n04_s10・flat_n02_l・flat_n02_s15・flat_n02_s10
    --ams     ：AMS 2 色（溝を黒で刷る。README の注意を参照）も作る
    --project ：スライスせずに、設定入りの Bambu Studio プロジェクト 3MF（print/<名前>_project.3mf）も作る（公開ページで配る形）
出力：print/<名前>[_ams]_P1S.3mf、print/slice_summary_<版>.txt、print/presets_<版>/
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
S03 = os.path.join(os.path.dirname(os.path.dirname(HERE)), "painting-03", "print")
sys.path.insert(0, S03)
argv, sys.argv = sys.argv[1:], sys.argv[:1]
import slice_p1s as S  # noqa: E402


def name_of(key):
    _, nz, sz = key.split("_")
    return f"engraved_fuji_pearl_flat_p1s_{nz}" + ("" if sz == "l" else f"_{sz}"), nz


def run(key, ams, project):
    name, nz = name_of(key)
    k = key + ("_ams" if ams else "")
    model = os.path.join(HERE, f"{name}_painted.3mf" if ams else f"print/{name}_plain.3mf")
    out = os.path.join(HERE, "print", f"{name}{'_ams' if ams else ''}_P1S.3mf")
    S.VARIANTS[k] = S.nozzle_variant(nz, ams, model=os.path.relpath(model, S03), out=os.path.relpath(out, S03))
    real = S.json.dump

    def dump(obj, f, **kw):                       # 工程の名前の作品名を、この作品に替える
        if isinstance(obj, dict) and isinstance(obj.get("name"), str):
            obj["name"] = obj["name"].replace("星月夜⇄風神雷神", "赤富士⇄真珠")
        return real(obj, f, **kw)
    S.json.dump = dump
    try:
        S.slice_variant(k)
    finally:
        S.json.dump = real
    pdir = os.path.join(HERE, "print", "presets_" + k)
    if os.path.exists(pdir):
        shutil.rmtree(pdir)
    shutil.move(os.path.join(S03, "presets_" + k), pdir)
    if project:                                   # 同じ設定で、スライスせずにプロジェクトとして書き出す
        fil = sorted(os.path.join(pdir, f) for f in os.listdir(pdir) if f.startswith("filament_"))
        proj = os.path.join(HERE, "print", f"{name}{'_ams' if ams else ''}_project.3mf")
        cmd = [S.BAMBU, "--orient", "0", "--arrange", "0",
               "--load-settings", os.path.join(pdir, "machine.json") + ";" + os.path.join(pdir, "process.json"),
               "--load-filaments", ";".join(fil), "--export-3mf", proj, model]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(proj):
            sys.exit(f"{k}: プロジェクトの書き出しに失敗しました\n{(r.stdout + r.stderr)[-2000:]}")
        print("プロジェクト:", proj, flush=True)


if __name__ == "__main__":
    for key in [a for a in argv if not a.startswith("--")]:
        run(key, False, "--project" in argv)
        if "--ams" in argv:
            run(key, True, "--project" in argv)
