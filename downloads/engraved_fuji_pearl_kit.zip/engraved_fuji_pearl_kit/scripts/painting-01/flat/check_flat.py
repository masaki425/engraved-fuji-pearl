"""スライス済み 3MF の G-code を設計の断面と重ねて調べる（painting-03/print/check_lands.py をこの版で動かす）。

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-01/flat/check_flat.py [版 ...]
出力：print/lands_report_<名前>[_ams].txt（スライス済みの版・色ごと）
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "painting-03", "print"))
import design_flat as F   # noqa: E402
import check_lands as C   # noqa: E402

F.install()
for key in sys.argv[1:] or list(F.PROFILES):
    for sfx in ("", "_ams"):
        path = os.path.join(HERE, "print", f"{F.PROFILES[key]['NAME']}{sfx}_P1S.3mf")
        if os.path.exists(path):                     # スライスしていない版・色は飛ばす
            sys.argv = [sys.argv[0], key, path]
            C.main()
