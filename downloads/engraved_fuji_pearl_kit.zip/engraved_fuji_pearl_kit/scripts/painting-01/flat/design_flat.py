"""線刻の変身画「赤富士 ⇄ 真珠の耳飾りの少女」の平らな版（painting-03 の方式）。

painting-01 のもとの方式（線の粗密で明暗を出す）では、上面に数 mm〜十数 mm の起伏ができ、刷ると凸凹が目立った。
この版は painting-03 の方式で作り直す：溝は等間隔で起伏はほぼなく（±0.3 mm 以内）、明暗は溝の間の面の見かけの幅だけで描く。
面の手前と奥の縁の高さを少し変えて、手前での幅と鏡での幅を別々に決め、傾きの陰影まで連立で打ち消す。
2026-09-30 から、打ち消しは実物の部屋の照明（天井からのやわらかい光）に合わせる（LIGHT="room"）。
それまでの Bambu Studio の表示の照明に合わせた打ち消しでは、実物で俯角 45° でも約 1 割透けた（FIX_PLAN.md）。
設計・メッシュ・3MF の書き出しは painting-03/design/design.py をそのまま使い、絵・大きさ・明暗の作り方だけをここで決める。

大きさは painting-01 の 3 つの版と同じ（板の外形・絵の部分）：
  大きい版（l）  ：板 180 × 246 mm、絵 160 × 160 mm（見かけ）
  長辺 15 cm（s15）：板 110 × 150 mm、絵 96 × 96 mm
  長辺 10 cm（s10）：板 73.5 × 100 mm、絵 64 × 64 mm
ノズルは 0.4 mm（P1S 標準）と 0.2 mm（別売。公開ページに載せる版）。溝の間隔（平面上）は painting-03 と同じ 1.92 mm・1.16 mm、
溝・面の最小幅と溝の深さも同じ（0.5 / 0.5 / 1.0 mm、0.35 / 0.3 / 0.8 mm）。

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-01/flat/design_flat.py [版 ...]
  版：flat_n04_l・flat_n04_s15・flat_n04_s10・flat_n02_l・flat_n02_s15・flat_n02_s10（省略時は 6 つとも）
出力（painting-01/flat/）：<名前>.stl、<名前>_painted.3mf（溝を 2 番目の色で塗った確認用・AMS 用）、print/<名前>_plain.3mf、
  views/sim_<名前>.png（Bambu Studio の照明での再現。左：手前、右：鏡の中）と _blur.png
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
P01 = os.path.dirname(HERE)
ROOT = os.path.dirname(P01)
sys.path.insert(0, os.path.join(ROOT, "painting-03", "design"))
import design as D  # noqa: E402

SRC = os.path.join(P01, "design", "source")
# 明暗は painting-01 と同じ作り方（lines_design.py の WEIGHTS・tone）。
#   赤富士は青を重く見る（青空・白い雲・雪は明るく、赤い山と緑の森は暗い）。
#   少女は局所的な明暗の差を 1.5 倍に強める（目・鼻・口を立てる。painting-01 の CONTRAST_B）
WEIGHTS = {"hokusai_red_fuji": (0.12, 0.30, 0.58), "vermeer_pearl_earring": (0.2126, 0.7152, 0.0722)}
LOCAL = {"hokusai_red_fuji": 0.0, "vermeer_pearl_earring": 1.5}

SIZES = {"l": (160.0, 10.0), "s15": (96.0, 7.125), "s10": (64.0, 4.75)}      # 絵の見かけの高さ H・周りの縁 BORDER [mm]
NOZ = {"n04": (1.92, 0.5, 0.5, 1.0), "n02": (1.16, 0.35, 0.3, 0.8)}   # 溝の間隔（平面上）・溝の最小幅・面の最小幅・溝の深さ [mm]
PROFILES = {}
for _nz, (_pitch, _gw, _lm, _gd) in NOZ.items():
    for _sz, (_h, _b) in SIZES.items():
        PROFILES[f"flat_{_nz}_{_sz}"] = dict(
            H=_h, N=int(round(_h / (_pitch * D.SIN_E))), NX=int(round(_h / 0.2)) + 1, GROOVE_W=_gw, LAND_MIN=_lm,
            GROOVE_D=_gd, BORDER=_b, BASE=3.5, NAME=f"engraved_fuji_pearl_flat_p1s_{_nz}" + ("" if _sz == "l" else f"_{_sz}"),
            A="hokusai_red_fuji", B="vermeer_pearl_earring", NZ=_nz, UVIEW=(0.18, 0.82), LIGHT="room")


def tone(name):
    """絵の暗さ t（0 = 最も明るい … 1 = 最も暗い）。ぼかしは Design.sample がかける。"""
    rgb = np.clip(np.load(os.path.join(SRC, name + ".npy")), 0, 1) ** (1 / 2.2)
    lum = rgb @ np.array(WEIGHTS[name], np.float32)
    if LOCAL[name] > 0:
        lum = lum + LOCAL[name] * (lum - D.blur(lum, 24.0, 24.0))
    lo, hi = np.percentile(lum, 1.5), np.percentile(lum, 98.5)
    return 1 - np.clip((lum - lo) / (hi - lo), 0, 1)


def install():
    """painting-03 の design モジュールを、この絵・この版で動くように差し替える（check_lands.py・build_blend.py からも使う）。"""
    D.ASPECT = 1.0
    D.tone = tone
    D.PROFILES.update(PROFILES)
    D.OUT_DIR = HERE
    return D


def build(key):
    install()
    prof = PROFILES[key]
    name = prof["NAME"]
    d = D.Design(prof)
    rep = d.validate()
    print(f"[{key}] {name}")
    for k, v in rep.items():
        print(f"  {k}: {v}")
    if not rep["ok"]:
        raise SystemExit(f"{key}: 検証に通りません")
    rows = d.NX
    a, b = d.render("A", rows), d.render("B", rows)
    os.makedirs(os.path.join(HERE, "views"), exist_ok=True)
    gap = np.ones((a.shape[0], 16))
    lo, hi = min(d.rng["A"][0], d.rng["B"][0]), max(d.rng["A"][1], d.rng["B"][1])
    D.write_png(os.path.join(HERE, "views", f"sim_{name}.png"), np.concatenate([(a - lo) / (hi - lo), gap, (b - lo) / (hi - lo)], 1))
    s = 0.8 * d.P / d.H * rows                                   # 線 1 本ぶんほどぼかす（少し離れて見た明暗）
    ab, bb = [(D.blur(im, s, s) - lo) / (hi - lo) for im in (a, b)]
    D.write_png(os.path.join(HERE, "views", f"sim_{name}_blur.png"), np.concatenate([ab, gap, bb], 1))
    V, T, INKF = d.mesh()
    chk = D.check_mesh(V, T)
    print("  mesh:", chk)
    if chk["unpaired_edges"] or chk["dup_directed_edges"] or chk["overhang_tris"]:
        raise SystemExit(f"{key}: 閉じた立体になっていません")
    os.makedirs(os.path.join(HERE, "print"), exist_ok=True)
    D.write_stl(os.path.join(HERE, name + ".stl"), V, T)
    D.write_painted_3mf(os.path.join(HERE, name + "_painted.3mf"), V, T, INKF, name)
    D.write_painted_3mf(os.path.join(HERE, "print", name + "_plain.3mf"), V, T, None, name)
    return rep, chk


if __name__ == "__main__":
    for k in sys.argv[1:] or list(PROFILES):
        build(k)
