"""線刻の変身画「赤富士 ⇄ 真珠の耳飾りの少女」の設計（numpy。Blender 同梱の Python で動く）。

直方体の上面に、左右いっぱいに走る細い溝を約 110 本彫り、墨を入れる。上面はほとんど平らに見える浅い起伏。
溝の間隔の粗密（線が詰まる所は暗く、まばらな所は明るい）が絵の明暗になる。
  手前から直接見ると　葛飾北斎「冨嶽三十六景 凱風快晴」（赤富士）
  後ろに立てた鏡の中では　フェルメール「真珠の耳飾りの少女」
が浮かび上がる。同じ溝が、見る向きによって別の位置に映るためで、塗り分けは一切ない。

原理（杉原厚吉「変身立体」）
  面上の点 (x, y, z) は、手前 A と奥 B から俯角 e で見ると、画面の上下位置が
      vA =  y sin e + (z - Z0) cos e,    vB = -y sin e + (z - Z0) cos e
  になる（鏡は奥行きだけを反転するので左右 x は共通）。1 枚の像には奥行きの情報がないので、
  溝 1 本ごとに 2 つの像での位置 (vA, vB) を別々に決めれば、溝の空間曲線が一意に決まる。
      y = (vA - vB) / (2 sin e),   z = Z0 + (vA + vB) / (2 cos e)
  見る人は「直方体の上面は平ら」と思い込むので、線は平らな板に彫られた版画として読まれる。

線の決め方（各列 x ごと）
  明暗 T（暗いほど 1）から線の密度 ρ = 1 + (R-1) T を作り、その累積分布を N 等分した位置に線を置く。
      手前の像：下から i 本目の線 = 赤富士の累積分布の (i+0.5)/N の位置
      鏡の像　：同じ線 = 少女の累積分布の 1-(i+0.5)/N の位置（並び順を逆にする）
  並び順が 2 つの像で逆なので、隣り合う線の間の面の奥行き方向の傾きは
      (ρB - ρA) / (ρB + ρA)  （|傾き| <= (R-1)/(R+1)）
  で抑えられ、R = 4 なら 0.6（約 31°）以下。俯角 45° のどちらの視点からも、面が面自身を隠さない。

実行すると検証結果を表示し、「設計どおりに見えたとき」の見本 design/preview_*.png を書き出す。
引数で造形方式を選ぶ（resin：光造形・等倍 / p1s_n04：Bambu Lab P1S 0.4 mm ノズル / p1s_n02：同 0.2 mm ノズル /
  p1s_n0?_iw：溝の幅を 2 つの絵で別々に決める版 / p1s_n0?_s10 / _s15：その長辺 10 / 15 cm 版）。
  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-01/design/lines_design.py [profile]
"""

import math
import os
import struct
import zlib

import numpy as np

# ---- 設計パラメータ ----
ELEV_DEG = 45.0
UNIT = 100.0            # 画面座標 1 あたりの長さ [mm]（絵の枠 [-1,1]^2 = 200mm 角）
N_LINES = 220           # 溝の本数
NX = 801                # 左右方向の分割数
R = 6.0                 # 線の密度の最大と最小の比（傾きの上限 (R-1)/(R+1) を決める）
GROOVE_W = 0.5          # 溝の幅（平面上）[mm]
GROOVE_D = 1.2          # 溝の深さ [mm]
LAND_MIN = 0.2          # 溝と溝の間に残す面の最小幅 [mm]
BLUR_V, BLUR_X = 1.8, 1.8   # 明暗をぼかす量 [画素]（線がなめらかになるように）
EDGE_PAD = 0.035        # 絵の上下の端に空ける余白（画面単位）

E = math.radians(ELEV_DEG)
SIN_E, COS_E = math.sin(E), math.cos(E)
HALF_W, HALF_D = UNIT, UNIT / SIN_E
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source")

# ---- 造形方式ごとの設定（apply_profile で切り替える） ----
#   border / base は Blender 側で使う（絵の周りの縁の幅、最も低い溝の底より下の厚み）[mm]
#   BLUR_X：左右方向のぼかし [画素]。面の高さは 2 つの絵の線の位置の和で決まるので、どちらかの絵に縦の輪郭があると
#   面が左右に急に傾き、照明によってはその陰影がもう一方の絵に縦の筋として透ける。12 画素（絵の幅の 1.5 %）で抑える
PROFILES = {
    # 光造形（レジン）で等倍。直方体 244 × 327 mm
    "resin": dict(UNIT=100.0, N_LINES=220, R=6.0, GROOVE_W=0.5, GROOVE_D=1.2, LAND_MIN=0.2,
                  BLUR=1.8, BLUR_X=12.0, border=22.0, base=8.0),
    # Bambu Lab P1S・標準 0.4 mm ノズル。造形エリア 256 × 256 mm に収まる直方体 180 × 246 mm
    #   溝 0.6 mm（押し出し幅 0.42 mm で閉じない幅）、溝の間の面 0.5 mm 以上（1 本の壁として出せる幅）
    #   線を 100 本に絞り、濃淡の比を 6 にして絵のコントラストを保つ（125 本・比 4 では赤富士が薄くなった）
    "p1s_n04": dict(UNIT=80.0, N_LINES=100, R=6.0, GROOVE_W=0.6, GROOVE_D=1.0, LAND_MIN=0.5,
                    BLUR=4.0, BLUR_X=12.0, border=10.0, base=4.0),
    # Bambu Lab P1S・0.2 mm ノズル（別売）。同じ大きさで溝を細かく
    "p1s_n02": dict(UNIT=80.0, N_LINES=190, R=6.0, GROOVE_W=0.35, GROOVE_D=0.8, LAND_MIN=0.3,
                    BLUR=2.1, BLUR_X=12.0, border=10.0, base=4.0),
    # 溝の幅を変える版：暗い所ほど溝を太くして、太さで濃淡を出す。そのぶん粗密の比 R を 2.5 に下げて起伏を浅くする
    #   GROOVE_W は最も細い溝の幅、WIDTH は溝の幅の決め方（"mean"：2 つの絵の暗さの平均、"max"：暗いほう）
    "p1s_n04_vw": dict(UNIT=80.0, N_LINES=100, R=2.5, GROOVE_W=0.5, GROOVE_D=1.0, LAND_MIN=0.5,
                       BLUR=4.0, BLUR_X=12.0, border=10.0, base=4.0, WIDTH="mean", W_GAMMA=1.0),
    "p1s_n02_vw": dict(UNIT=80.0, N_LINES=190, R=2.5, GROOVE_W=0.35, GROOVE_D=0.8, LAND_MIN=0.3,
                       BLUR=2.1, BLUR_X=12.0, border=10.0, base=4.0, WIDTH="mean", W_GAMMA=1.0),
    # 溝の幅を 2 つの絵で別々に決める版（WIDTH="indep"）。溝の手前の縁と奥の縁の高さを変えると、
    #   手前から見た溝の幅と鏡から見た溝の幅を独立に決められる（縁 1 本ずつに変身立体の式を当てる）。
    #   溝の位置（起伏）は左右に強くぼかした明暗（BLUR_X）で決めてなめらかに保ち、細部は左右のぼかしが
    #   小さい明暗（BLUR_F）による溝の幅で出す。幅の違いは相手の絵に映らないので、少女の目・鼻・口が出せる。
    #   C_MIN / C_MAX：線の間隔に対する溝の見かけの幅の割合（明るい所 / 暗い所）
    #   0.4 mm ノズル版は、線 100 本では上下方向の細かさ（線の間隔 1.6 mm）が足りず、目や口が出なかった。
    #   R を 2.5 に下げて密な所の間隔を広げ、溝 0.5 mm・面 0.5 mm を保てる上限近くの 140 本に増やす
    "p1s_n04_iw": dict(UNIT=80.0, N_LINES=140, R=2.5, GROOVE_W=0.5, GROOVE_D=1.0, LAND_MIN=0.5,
                       BLUR=2.0, BLUR_X=12.0, border=10.0, base=4.0, WIDTH="indep", W_GAMMA=1.0,
                       BLUR_F=1.5, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5),
    "p1s_n02_iw": dict(UNIT=80.0, N_LINES=190, R=3.0, GROOVE_W=0.35, GROOVE_D=0.8, LAND_MIN=0.3,
                       BLUR=1.5, BLUR_X=12.0, border=10.0, base=4.0, WIDTH="indep", W_GAMMA=1.0,
                       BLUR_F=1.2, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5),
    # 長辺 10 cm の小型版（直方体 73.5 × 100 mm）。絵の部分を 64 × 90.5 mm（UNIT 32 = 大きい版の 0.4 倍）にする。
    #   溝と壁の最小幅はノズルで決まるので縮めず、線の本数を減らす。大きい版と同じ線の密度なら 0.2 mm 版 76 本・
    #   0.4 mm 版 56 本。0.2 mm 版は、溝の幅を変えられる余地を保てる範囲で 90 本まで増やした（104 本・R 2.5 では
    #   溝の 3 割が最小幅に張り付いて、富士の明暗が薄くなった）
    #   scene_scale：Blender の鏡・斜めのカメラ・周回カメラの大きさと距離の倍率
    "p1s_n02_s10": dict(UNIT=32.0, N_LINES=90, R=3.0, GROOVE_W=0.35, GROOVE_D=0.8, LAND_MIN=0.3,
                        BLUR=1.5, BLUR_X=12.0, border=4.75, base=3.0, WIDTH="indep", W_GAMMA=1.0,
                        BLUR_F=1.2, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5, scene_scale=0.4),
    "p1s_n04_s10": dict(UNIT=32.0, N_LINES=56, R=2.5, GROOVE_W=0.5, GROOVE_D=1.0, LAND_MIN=0.5,
                        BLUR=2.0, BLUR_X=12.0, border=4.75, base=3.0, WIDTH="indep", W_GAMMA=1.0,
                        BLUR_F=1.5, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5, scene_scale=0.4),
    # 長辺 15 cm 版（直方体 110 × 150 mm）。絵の部分を 96 × 136 mm（UNIT 48 = 大きい版の 0.6 倍）にする。
    #   線の本数は 10 cm 版と同じ密度（0.2 mm 版 136 本・0.4 mm 版 84 本）。10 / 12.5 / 15 cm を比べて、
    #   少女の目・鼻・口が読めたのは 0.2 mm 版の 15 cm だけだった
    "p1s_n02_s15": dict(UNIT=48.0, N_LINES=136, R=3.0, GROOVE_W=0.35, GROOVE_D=0.8, LAND_MIN=0.3,
                        BLUR=1.5, BLUR_X=12.0, border=7.125, base=4.0, WIDTH="indep", W_GAMMA=1.0,
                        BLUR_F=1.2, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5, scene_scale=0.6),
    "p1s_n04_s15": dict(UNIT=48.0, N_LINES=84, R=2.5, GROOVE_W=0.5, GROOVE_D=1.0, LAND_MIN=0.5,
                        BLUR=2.0, BLUR_X=12.0, border=7.125, base=4.0, WIDTH="indep", W_GAMMA=1.0,
                        BLUR_F=1.5, C_MIN=0.10, C_MAX=0.80, CONTRAST_B=1.5, scene_scale=0.6),
}
SLOPE_MAX = 0.75        # 溝の間の面の奥行き方向の傾きの上限（45° の視線に対して余裕を残す）
WIDTH, W_GAMMA = None, 1.0
BLUR_F, C_MIN, C_MAX, CONTRAST_B = 1.5, 0.1, 0.8, 0.0
PROFILE = "resin"


def apply_profile(name):
    """造形方式の設定を、このモジュールの定数に反映する（Design() を作る前に呼ぶ）。"""
    global UNIT, N_LINES, R, GROOVE_W, GROOVE_D, LAND_MIN, BLUR_V, BLUR_X, HALF_W, HALF_D, PROFILE, WIDTH, W_GAMMA
    global BLUR_F, C_MIN, C_MAX, CONTRAST_B
    p = PROFILES[name]
    UNIT, N_LINES, R = p["UNIT"], p["N_LINES"], p["R"]
    GROOVE_W, GROOVE_D, LAND_MIN = p["GROOVE_W"], p["GROOVE_D"], p["LAND_MIN"]
    BLUR_V = p["BLUR"]
    BLUR_X = p.get("BLUR_X", p["BLUR"])   # 左右方向のぼかし（大きいほど左右の急な傾きが減る）
    HALF_W, HALF_D = UNIT, UNIT / SIN_E
    WIDTH, W_GAMMA = p.get("WIDTH"), p.get("W_GAMMA", 1.0)
    BLUR_F, C_MIN, C_MAX = p.get("BLUR_F", 1.5), p.get("C_MIN", 0.1), p.get("C_MAX", 0.8)
    CONTRAST_B = p.get("CONTRAST_B", 0.0)
    PROFILE = name
    return p


PAINT_A = "hokusai_red_fuji"          # 手前から見る絵（明暗の配列は上の行が絵の上）
PAINT_B = "vermeer_pearl_earring"     # 鏡の中の絵


# =====================================================================
#  明暗と線の密度
# =====================================================================

def _gauss(sigma):
    r = int(3 * sigma) + 1
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    return k / k.sum()


def _blur(a, sv, sx):
    kv, kx = _gauss(sv), _gauss(sx)
    a = np.apply_along_axis(lambda c: np.convolve(np.pad(c, len(kv) // 2, mode="edge"), kv, "valid"), 0, a)
    a = np.apply_along_axis(lambda r: np.convolve(np.pad(r, len(kx) // 2, mode="edge"), kx, "valid"), 1, a)
    return a


# 明るさの作り方（RGB の重み）。赤富士は青を重く見て、青空・白い雲・雪を明るく、赤い山と緑の森を暗くする
WEIGHTS = {"hokusai_red_fuji": (0.12, 0.30, 0.58), "vermeer_pearl_earring": (0.2126, 0.7152, 0.0722)}


def tone(name, sx=None, local=0.0):
    """絵の暗さ T（0 = 最も明るい … 1 = 最も暗い）。上の行が絵の上。
    sx：左右方向のぼかし [画素]（省略時 BLUR_X）。local > 0 なら局所的な明暗の差を強める（目・鼻・口を立てる）。"""
    rgb = np.clip(np.load(os.path.join(SRC, name + ".npy")), 0, 1) ** (1 / 2.2)   # 見た目の明るさに近づける
    lum = rgb @ np.array(WEIGHTS[name], np.float32)
    if local > 0:
        base = _blur(lum, 24.0, 24.0)
        lum = lum + local * (lum - base)
    lo, hi = np.percentile(lum, 1.5), np.percentile(lum, 98.5)
    t = 1 - np.clip((lum - lo) / (hi - lo), 0, 1)
    return _blur(t, BLUR_V, BLUR_X if sx is None else sx)


def line_positions(T, reverse):
    """各列で、密度 1 + (R-1)T の累積分布を N 等分した位置に線を置く。戻り値 [N, NX]（画面の v）。"""
    n = T.shape[0]
    v = np.linspace(1 - EDGE_PAD, -1 + EDGE_PAD, n)             # 行 0 = 絵の上
    cols = np.clip(np.round((np.linspace(-1, 1, NX) + 1) / 2 * (T.shape[1] - 1)).astype(int), 0, T.shape[1] - 1)
    t = (np.arange(N_LINES) + 0.5) / N_LINES
    if reverse:
        t = 1 - t
    out = np.empty((N_LINES, NX))
    vv = v[::-1]                                                  # 下から上
    for j, c in enumerate(cols):
        rho = 1 + (R - 1) * T[::-1, c]
        cdf = np.concatenate([[0], np.cumsum((rho[1:] + rho[:-1]) / 2 * np.diff(vv))])
        cdf /= cdf[-1]
        out[:, j] = np.interp(t, cdf, vv)
    return out


# =====================================================================
#  3 次元化と検証
# =====================================================================

class Design:
    def __init__(self):
        self.x = np.linspace(-1, 1, NX)
        self.TA, self.TB = tone(PAINT_A), tone(PAINT_B)
        self.A = line_positions(self.TA, reverse=False)     # 下から i 本目
        self.B = line_positions(self.TB, reverse=True)      # 同じ線の鏡の中の位置（上から i 本目）
        self.Y = (self.A - self.B) / (2 * SIN_E) * UNIT
        rel = (self.A + self.B) / (2 * COS_E) * UNIT
        if WIDTH == "indep":
            # 溝の縁ごとの (vA, vB)。縁の低い y 側は、手前の像では溝の下の縁、鏡の像では上の縁
            a, b = self.indep_widths()
            self.a, self.b = a, b
            elo_a, elo_b = self.A - a / 2, self.B + b / 2
            ehi_a, ehi_b = self.A + a / 2, self.B - b / 2
            ylo, rlo = (elo_a - elo_b) / (2 * SIN_E) * UNIT, (elo_a + elo_b) / (2 * COS_E) * UNIT
            yhi, rhi = (ehi_a - ehi_b) / (2 * SIN_E) * UNIT, (ehi_a + ehi_b) / (2 * COS_E) * UNIT
        else:
            w = self.groove_widths()
            ylo, yhi, rlo, rhi = self.Y - w / 2, self.Y + w / 2, rel, rel
        # 絵の枠（上面の縁取り）の高さ Z0。起伏の最も低い溝の底が、枠の面から大きく下がりすぎないようにする
        self.Z0 = float(math.ceil(max(0.0, -min(rlo.min(), rhi.min())) + GROOVE_D + 6.0))
        self.Z = self.Z0 + rel
        self.Ylo, self.Yhi = ylo, yhi                  # 溝の手前（y の小さい側）と奥の縁
        self.Zlo, self.Zhi = self.Z0 + rlo, self.Z0 + rhi
        self.W = yhi - ylo                             # 溝の幅（平面上）

    def _sample(self, T, v):
        """暗さの配列 T を、各溝の位置（列 x、画面の高さ v）で読む。"""
        n, m = T.shape
        rows = (1 - EDGE_PAD - v) / (2 - 2 * EDGE_PAD) * (n - 1)
        cols = np.broadcast_to((self.x + 1) / 2 * (m - 1), v.shape)
        r0 = np.clip(np.floor(rows).astype(int), 0, n - 2)
        c0 = np.clip(np.round(cols).astype(int), 0, m - 1)
        f = np.clip(rows - r0, 0, 1)
        return T[r0, c0] * (1 - f) + T[r0 + 1, c0] * f

    def groove_widths(self):
        """溝の幅 [N, NX]。WIDTH が None なら一定。そうでなければ、その溝の暗さに応じて
        最も細い幅 GROOVE_W から「隣の溝との間に LAND_MIN を残せる最大の幅」まで太くする。"""
        W = np.full_like(self.Y, GROOVE_W)
        if not WIDTH:
            return W
        ta, tb = self._sample(self.TA, self.A), self._sample(self.TB, self.B)
        t = (ta + tb) / 2 if WIDTH == "mean" else np.maximum(ta, tb)
        dY = np.diff(self.Y, axis=0)
        gap = np.minimum(np.vstack([dY[:1], dY]), np.vstack([dY, dY[-1:]]))
        wmax = np.maximum(gap - LAND_MIN, GROOVE_W)
        W = GROOVE_W + (wmax - GROOVE_W) * np.clip(t, 0, 1) ** W_GAMMA
        W = _blur(W, 0.01, 3.0)                      # 左右方向に少しなめらかに（溝の縁のぎざつきを防ぐ）
        return np.clip(W, GROOVE_W, wmax)

    def indep_widths(self):
        """手前の像での溝の見かけの幅 a と、鏡の像での幅 b（画面単位）[N, NX]。
        それぞれの絵の細かい明暗（左右のぼかし BLUR_F）で、線の間隔の C_MIN 〜 C_MAX 倍にする。
        制約：溝の幅（平面上）= (a + b) UNIT / (2 sin e) >= GROOVE_W、
              溝の間の面の幅 = (gA + gB) UNIT / (2 sin e) >= LAND_MIN（gA, gB は各像での面の見かけの幅）、
              面の傾き (gA - gB) / (gA + gB) <= SLOPE_MAX（45° の視線で面が隠れないように）"""
        k = UNIT / (2 * SIN_E)
        wsum, gsum = GROOVE_W / k, LAND_MIN / k
        fa = tone(PAINT_A, BLUR_F)
        fb = tone(PAINT_B, BLUR_F, CONTRAST_B)
        ta, tb = self._sample(fa, self.A), self._sample(fb, self.B)
        dA = np.diff(self.A, axis=0)                  # > 0
        dB = -np.diff(self.B, axis=0)                 # > 0（鏡の像では並びが逆）

        def pitch(d):                                 # 溝ごとの、隣との間隔の小さいほう
            return np.minimum(np.vstack([d[:1], d]), np.vstack([d, d[-1:]]))
        pA, pB = pitch(dA), pitch(dB)
        cov = lambda t: C_MIN + (C_MAX - C_MIN) * np.clip(t, 0, 1) ** W_GAMMA
        a, b = cov(ta) * pA, cov(tb) * pB
        smin = (1 - SLOPE_MAX) / (1 + SLOPE_MAX)
        for _ in range(60):
            # 溝が細すぎれば、両方の像で同じだけ太くする
            short = np.maximum(wsum - (a + b), 0)
            a, b = a + short / 2, b + short / 2
            gA = dA - (a[1:] + a[:-1]) / 2
            gB = dB - (b[1:] + b[:-1]) / 2
            # 面の傾きと面の幅：見かけの幅の小さいほうの像で、両側の溝を細くして面を広げる
            needA = np.maximum(smin * gB, 0) - gA
            needB = np.maximum(smin * gA, 0) - gB
            lack = gsum - (gA + gB)
            needA = np.maximum(needA, np.where(lack > 0, lack * dA / (dA + dB), 0))
            needB = np.maximum(needB, np.where(lack > 0, lack * dB / (dA + dB), 0))
            if needA.max() <= 1e-9 and needB.max() <= 1e-9 and short.max() <= 1e-9:
                break
            for w, need in ((a, needA), (b, needB)):
                cut = np.maximum(need, 0) * 1.02
                w[1:] -= cut
                w[:-1] -= cut
            a, b = np.maximum(a, 0), np.maximum(b, 0)
        return a, b

    def validate(self, verbose=True):
        dY = np.diff(self.Y, axis=0)
        land = self.Ylo[1:] - self.Yhi[:-1]
        slope = np.abs((self.Zlo[1:] - self.Zhi[:-1]) / land)
        rep = {"Z0": self.Z0, "lines": N_LINES,
               "relief_mm": (float(min(self.Zlo.min(), self.Zhi.min()) - self.Z0),
                             float(max(self.Zlo.max(), self.Zhi.max()) - self.Z0)),
               "min_line_spacing_mm": float(dY.min()),
               "min_land_mm": float(land.min()),
               "groove_w_mm": (float(self.W.min()), float(self.W.max())),
               "edge_step_mm": float(np.abs(self.Zhi - self.Zlo).max()),
               "max_slope_y": float(slope.max()),
               "max_slope_x": float(np.abs(np.gradient(self.Z, self.x * UNIT, axis=1)).max()),
               "y_range": (float(self.Y.min()), float(self.Y.max()))}
        rep["ok"] = bool(rep["min_land_mm"] >= LAND_MIN - 1e-6 and rep["groove_w_mm"][0] >= GROOVE_W - 1e-6
                         and rep["max_slope_y"] < 0.8
                         and rep["y_range"][0] > -HALF_D and rep["y_range"][1] < HALF_D)
        if verbose:
            for k, v in rep.items():
                print(f"  {k}: {v}")
        return rep

    def reproject_error(self):
        va = (self.Y * SIN_E + (self.Z - self.Z0) * COS_E) / UNIT
        vb = (-self.Y * SIN_E + (self.Z - self.Z0) * COS_E) / UNIT
        return float(max(np.abs(va - self.A).max(), np.abs(vb - self.B).max()))

    def edges(self, view):
        """その視点から見た各溝の口の範囲（画面の v の小さいほう, 大きいほう）[N, NX]。"""
        s = 1 if view == "A" else -1
        e1 = (s * self.Ylo * SIN_E + (self.Zlo - self.Z0) * COS_E) / UNIT
        e2 = (s * self.Yhi * SIN_E + (self.Zhi - self.Z0) * COS_E) / UNIT
        return np.minimum(e1, e2), np.maximum(e1, e2)

    def preview(self, view, n=1000):
        """見本：各溝を、その視点から見た溝の口の幅（手前の縁 〜 奥の縁）の墨の帯として描く。
        面の傾きが 45° より緩いので隠れはなく、帯を描くだけで見え方が決まる。"""
        LO, HI = self.edges(view)
        img = np.ones((n, n, 3), np.float32) * np.array([0.90, 0.83, 0.70], np.float32)
        ink = np.array([0.08, 0.07, 0.07], np.float32)
        vs = 1 - (np.arange(n) + 0.5) * 2 / n
        xs = np.linspace(-1, 1, n)
        cols = np.clip(np.round((xs + 1) / 2 * (NX - 1)).astype(int), 0, NX - 1)
        px = 2 / n
        for j, c in enumerate(cols):
            lo, hi = LO[:, c], HI[:, c]
            cov = np.clip((np.minimum(hi[:, None], vs[None, :] + px / 2)
                           - np.maximum(lo[:, None], vs[None, :] - px / 2)) / px, 0, 1).sum(0)
            cov = np.clip(cov, 0, 1)[:, None]
            img[:, j] = img[:, j] * (1 - cov) + ink * cov
        return img


def write_png(path, img):
    a = (np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8)
    h, w, _ = a.shape
    raw = b"".join(b"\x00" + a[i].tobytes() for i in range(h))

    def chunk(t, dd):
        c = struct.pack(">I", len(dd)) + t + dd
        return c + struct.pack(">I", zlib.crc32(t + dd) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)


def main():
    import sys
    name = sys.argv[1] if len(sys.argv) > 1 else "resin"
    apply_profile(name)
    print("profile:", name)
    d = Design()
    print("validation:")
    rep = d.validate()
    print(f"  reprojection error: {d.reproject_error():.2e}")
    sfx = "" if name == "resin" else f"_{name}"
    write_png(os.path.join(HERE, f"preview_A_red_fuji{sfx}.png"), d.preview("A"))
    write_png(os.path.join(HERE, f"preview_B_pearl_earring{sfx}.png"), d.preview("B"))
    print("wrote previews", "OK" if rep["ok"] else "NG")


if __name__ == "__main__":
    main()
