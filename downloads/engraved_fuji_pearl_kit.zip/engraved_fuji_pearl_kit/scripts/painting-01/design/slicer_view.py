"""スライサー（Bambu Studio）の画面での見え方を、設計から直接描く（numpy。墨なし・形だけ）。

Bambu Studio（PrusaSlicer 系）の既定の照明をまねる：カメラに付いた 2 つの平行光と環境光。
  上の光 (-0.457, 0.457, 0.762) 拡散 0.8、正面の光 (0.699, 0.140, 0.699) 拡散 0.3、環境光 0.3（カメラ座標）
俯角 45° の平行投影で、手前（赤富士）と奥（少女。鏡像ではなく直接見た向き）から見る。
溝は左右に走るので、列 x ごとの断面（縁 → 溝の 4 点 → … → 縁）で隠れと陰影が決まる。
面の左右の傾き（列どうしの差）も法線に入れる。

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-01/design/slicer_view.py <profile> [...]
出力：design/slicer_A_<profile>.png、design/slicer_B_<profile>.png、design/slicer_<profile>.png（並べたもの）
"""

import os
import sys

import numpy as np

import lines_design as LD

L_TOP = np.array([-0.4574957, 0.4574957, 0.7624929])
L_FRONT = np.array([0.6985074, 0.1397015, 0.6985074])
COLOR = np.array([0.93, 0.90, 0.84])          # 白っぽい PLA


def sections(d):
    """列ごとの断面の点 (Y, Z) [NX, P]。build_lines.build_block と同じ並び。"""
    nx, N = LD.NX, LD.N_LINES
    P = 2 + 4 * N
    Y = np.empty((nx, P))
    Z = np.empty((nx, P))
    Y[:, 0], Z[:, 0] = -LD.HALF_D, d.Z0
    Y[:, -1], Z[:, -1] = LD.HALF_D, d.Z0
    ylo, yhi, zlo, zhi = d.Ylo.T, d.Yhi.T, d.Zlo.T, d.Zhi.T
    zb = np.minimum(zlo, zhi) - LD.GROOVE_D
    Y[:, 1:-1:4], Z[:, 1:-1:4] = ylo, zlo
    Y[:, 2:-1:4], Z[:, 2:-1:4] = ylo, zb
    Y[:, 3:-1:4], Z[:, 3:-1:4] = yhi, zb
    Y[:, 4:-1:4], Z[:, 4:-1:4] = yhi, zhi
    return Y, Z


def render(d, view, n=1200):
    s = 1 if view == "A" else -1
    S, C = LD.SIN_E, LD.COS_E
    Y, Z = sections(d)
    xs = d.x * LD.UNIT
    # 各線分の中点の左右の傾き (dY/dx, dZ/dx)
    ym, zm = (Y[:, 1:] + Y[:, :-1]) / 2, (Z[:, 1:] + Z[:, :-1]) / 2
    gy, gz = np.gradient(ym, xs, axis=0), np.gradient(zm, xs, axis=0)
    dy, dz = np.diff(Y, axis=1), np.diff(Z, axis=1)
    # 法線 = (1, gy, gz) × (0, dy, dz)
    nxw, nyw, nzw = gy * dz - gz * dy, -dz, dy
    nn = np.sqrt(nxw ** 2 + nyw ** 2 + nzw ** 2) + 1e-12
    nxw, nyw, nzw = nxw / nn, nyw / nn, nzw / nn
    # カメラ座標（x 右、y 上、z 視点の方向）。奥から見るときは左右も反転
    cz = -s * C * nyw + S * nzw
    cy = s * S * nyw + C * nzw
    cx = s * nxw
    shade = 0.3 + 0.8 * np.maximum(0, cx * L_TOP[0] + cy * L_TOP[1] + cz * L_TOP[2]) \
        + 0.3 * np.maximum(0, cx * L_FRONT[0] + cy * L_FRONT[1] + cz * L_FRONT[2])
    V = (s * Y * S + (Z - d.Z0) * C) / LD.UNIT          # 画面の上下位置
    if s < 0:                                           # 視点に近い側から順に並べる
        V, shade = V[:, ::-1], shade[:, ::-1]
    img = np.zeros((n, n))
    vs = 1 - (np.arange(n) + 0.5) * 2 / n
    px = 2 / n
    cols = np.clip(np.round((np.linspace(-1, 1, n) + 1) / 2 * (LD.NX - 1)).astype(int), 0, LD.NX - 1)
    for j, c in enumerate(cols):
        v = V[c]
        runmax = np.maximum.accumulate(v)
        lo, hi = runmax[:-1], v[1:]                      # 線分の見えている範囲 [始点までの最大, 終点]
        ok = hi > lo
        lo, hi, sh = lo[ok], hi[ok], shade[c][ok]
        cov = np.clip((np.minimum(hi[:, None], vs[None, :] + px / 2)
                       - np.maximum(lo[:, None], vs[None, :] - px / 2)) / px, 0, 1)
        tot = cov.sum(0)
        img[:, j] = (cov * sh[:, None]).sum(0) / np.maximum(tot, 1e-9)
        img[tot < 1e-6, j] = 0.3
    if s < 0:
        img = img[:, ::-1]                             # 奥から直接見た向き（左右反転）
    rgb = np.clip(img[..., None] * COLOR, 0, 1)
    return rgb


def main():
    names = sys.argv[1:] or ["p1s_n02_iw"]
    here = os.path.dirname(os.path.abspath(__file__))
    for name in names:
        LD.apply_profile(name)
        d = LD.Design()
        a, b = render(d, "A"), render(d, "B")
        LD.write_png(os.path.join(here, f"slicer_A_{name}.png"), a)
        LD.write_png(os.path.join(here, f"slicer_B_{name}.png"), b)
        gap = np.ones((a.shape[0], 16, 3))
        LD.write_png(os.path.join(here, f"slicer_{name}.png"), np.concatenate([a, gap, b[:, ::-1]], 1))
        print("wrote", name)


if __name__ == "__main__":
    main()
