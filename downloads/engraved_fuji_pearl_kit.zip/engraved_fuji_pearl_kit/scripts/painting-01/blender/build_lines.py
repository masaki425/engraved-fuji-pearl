"""線刻の変身画「赤富士 ⇄ 真珠の耳飾りの少女」を Blender で組み立てる。

design/lines_design.py の設計から、上面を彫った 1 つの直方体を作り、.blend と STL を保存する。
  - 上面の絵の部分：ほとんど平らに見える浅い起伏に、左右いっぱいの細い溝を 220 本彫り、溝に墨を入れる
      手前から見ると北斎「凱風快晴」、後ろの鏡の中ではフェルメール「真珠の耳飾りの少女」
  - 絵の周りの縁：高さ Z0 の平らな面（両方の絵の額縁になる）
  - 塗りは木地と墨の 2 つだけ。どちらから見ても同じ（見る向きによる塗り分けはしない）
  - 少し前に倒した鏡、テーブル、前後対称の照明、カメラ（手前 / 奥 / 鏡を入れた展示写真 / 斜め / 真上 / 周回）

実行（プロジェクト直下 illusion-works/ から。GPU 検出のためサンドボックス外で）:
  /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup \
      --python painting-01/blender/build_lines.py -- [--profile resin|p1s_n04|p1s_n02|p1s_n04_iw|p1s_n02_iw|p1s_n04_s10|p1s_n02_s10|p1s_n04_s15|p1s_n02_s15] [--render] [--quick] [--video]
"""

import math
import os
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                      # painting-01/
sys.path.insert(0, os.path.join(ROOT, "design"))
import lines_design as LD  # noqa: E402

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
DO_RENDER = "--render" in args
QUICK = "--quick" in args
DO_VIDEO = "--video" in args
PROFILE = args[args.index("--profile") + 1] if "--profile" in args else "resin"
PROF = LD.apply_profile(PROFILE)
SFX = "" if PROFILE == "resin" else f"_{PROFILE}"
if "--blur-x" in args:                      # 試作用：左右のぼかしを変えた版（出力名に _bx<値> を付ける）
    LD.BLUR_X = float(args[args.index("--blur-x") + 1])
    SFX += f"_bx{args[args.index('--blur-x') + 1]}"

BLEND_OUT = os.path.join(ROOT, f"engraved_fuji_pearl{SFX}.blend")
STL_OUT = os.path.join(ROOT, f"engraved_fuji_pearl{SFX}.stl")
RENDER_DIR = os.path.join(ROOT, f"renders{SFX}")

D = LD.Design()
E, SIN_E, COS_E, UNIT = LD.E, LD.SIN_E, LD.COS_E, LD.UNIT
Z0 = D.Z0
HW, HD = LD.HALF_W, LD.HALF_D     # 絵の部分の半幅・半奥行き [mm]
BORDER = PROF["border"]           # 絵の周りの縁の幅 [mm]
BASE = PROF["base"]               # 起伏の最も低い溝の底より下の厚み [mm]
LIT = 0.0                         # 色のうち照明によらずに出す割合。実物どおりに描くため 0（以前の公開画像は 0.8 で陰影を抑えていた）
ORBIT_FRAMES = 240
BOTTOM = float(min(D.Zlo.min(), D.Zhi.min()) - LD.GROOVE_D - BASE)   # 直方体の底の高さ


# ---------------------------------------------------------------- 材質
def srgb_to_linear(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def lin(hexcol):
    h = hexcol.lstrip("#")
    return tuple(srgb_to_linear(int(h[i:i + 2], 16) / 255) for i in (0, 2, 4))


def plain(name, rgb, rough=0.6, metallic=0.0):
    m = bpy.data.materials.new(name)
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metallic
    m.diffuse_color = (*rgb, 1)
    return m


def paper(name, rgb, rough=0.7):
    """拡散反射に同じ色の弱い発光を混ぜる。起伏の陰影は向きによらず同じだが、
    手前と鏡の像では別の位置に映るので、絵に混ざらないよう弱める。"""
    m = bpy.data.materials.new(name)
    nt = m.node_tree
    out = nt.nodes["Material Output"]
    b = nt.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value = (*rgb, 1)
    mixn = nt.nodes.new("ShaderNodeMixShader")
    mixn.inputs["Fac"].default_value = LIT
    nt.links.new(b.outputs["BSDF"], mixn.inputs[1])
    nt.links.new(em.outputs["Emission"], mixn.inputs[2])
    nt.links.new(mixn.outputs["Shader"], out.inputs["Surface"])
    m.diffuse_color = (*rgb, 1)
    return m


def link(ob, coll):
    coll.objects.link(ob)
    return ob


# ---------------------------------------------------------------- 彫った直方体
MAT_WOOD, MAT_INK = 0, 1


def build_block(coll, materials):
    """列ごとの断面（縁 → 溝 → … → 縁）を左右につなぎ、周りの縁・側面・底を付けて閉じた立体にする。"""
    nx, N = LD.NX, LD.N_LINES
    xs = D.x * UNIT
    dep = LD.GROOVE_D
    # 断面の点：手前の縁 (−HD, Z0)、各溝の 4 点（面の縁・底・底・面の縁）、奥の縁 (HD, Z0)
    P = 2 + 4 * N
    Y = np.empty((nx, P))
    Zp = np.empty((nx, P))
    Y[:, 0], Zp[:, 0] = -HD, Z0
    Y[:, -1], Zp[:, -1] = HD, Z0
    # 溝の手前の縁 (ylo, zlo) と奥の縁 (yhi, zhi)。幅を 2 つの絵で別々に決める版では、縁の高さが違う
    ylo, yhi, zlo, zhi = D.Ylo.T, D.Yhi.T, D.Zlo.T, D.Zhi.T     # [nx, N]
    zb = np.minimum(zlo, zhi) - dep
    Y[:, 1:-1:4], Zp[:, 1:-1:4] = ylo, zlo
    Y[:, 2:-1:4], Zp[:, 2:-1:4] = ylo, zb
    Y[:, 3:-1:4], Zp[:, 3:-1:4] = yhi, zb
    Y[:, 4:-1:4], Zp[:, 4:-1:4] = yhi, zhi
    seg_mat = np.full(P - 1, MAT_WOOD)
    for k in range(N):                           # 溝の前壁・底・後壁は墨
        seg_mat[1 + 4 * k: 4 + 4 * k] = MAT_INK
    verts = np.stack([np.repeat(xs, P), Y.ravel(), Zp.ravel()], 1)
    idx = np.arange(nx * P).reshape(nx, P)
    a, b = idx[:-1, :-1], idx[1:, :-1]
    c, d = idx[1:, 1:], idx[:-1, 1:]
    faces = np.stack([a, b, c, d], -1).reshape(-1, 4).tolist()
    mats = np.tile(seg_mat, nx - 1).tolist()

    extra_v = []

    def V(x, y, z):
        extra_v.append((x, y, z))
        return len(verts) + len(extra_v) - 1

    # 左右の段差の壁（断面と高さ Z0 の線の間）
    for side, j in ((-1, 0), (1, nx - 1)):
        tops = [V(xs[j], Y[j, p], Z0) for p in range(P)]
        for p in range(P - 1):
            q = [idx[j, p], idx[j, p + 1], tops[p + 1], tops[p]]
            faces.append(q if side > 0 else q[::-1])
            mats.append(MAT_WOOD)
        if side < 0:
            left_tops = tops
        else:
            right_tops = tops
    # 周りの縁（高さ Z0）
    ox, oy = HW + BORDER, HD + BORDER
    o = [V(-ox, -oy, Z0), V(ox, -oy, Z0), V(ox, oy, Z0), V(-ox, oy, Z0)]
    front = idx[:, 0].tolist()
    back = idx[:, -1].tolist()
    faces.append([o[0], o[1]] + front[::-1]); mats.append(MAT_WOOD)
    faces.append([o[2], o[3]] + back); mats.append(MAT_WOOD)
    faces.append([o[1], o[2]] + right_tops[::-1]); mats.append(MAT_WOOD)
    faces.append([o[3], o[0]] + left_tops); mats.append(MAT_WOOD)
    u = [V(-ox, -oy, BOTTOM), V(ox, -oy, BOTTOM), V(ox, oy, BOTTOM), V(-ox, oy, BOTTOM)]
    for k in range(4):
        faces.append([u[k], u[(k + 1) % 4], o[(k + 1) % 4], o[k]]); mats.append(MAT_WOOD)
    faces.append(u[::-1]); mats.append(MAT_WOOD)

    allv = np.vstack([verts, np.array(extra_v)])
    me = bpy.data.meshes.new("EngravedBlock")
    me.from_pydata(allv.tolist(), [], faces)
    me.update()
    for m in materials:
        me.materials.append(m)
    me.polygons.foreach_set("material_index", mats)
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=1e-6)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    return link(bpy.data.objects.new("EngravedBlock", me), coll)


def manifold_report(ob):
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    nm = sum(1 for e in bm.edges if not e.is_manifold)
    info = dict(verts=len(bm.verts), faces=len(bm.faces), non_manifold_edges=nm)
    bm.free()
    return info


# ---------------------------------------------------------------- 視点・鏡
SS = PROF.get("scene_scale", 1.0)   # 小型版では鏡・カメラの大きさと距離を縮める
CAM_DIST = 3000.0 * SS
MIRROR_EXTRA = 340.0 * SS
TARGET = Vector((0, 0, Z0))


def view_dir(sign):
    return Vector((0, sign * COS_E, SIN_E))


def look_at(ob, target):
    ob.rotation_euler = (target - ob.location).to_track_quat("-Z", "Y").to_euler()


def make_camera(name, coll, loc, target, ortho=None, lens=50):
    cam = bpy.data.cameras.new(name)
    if ortho:
        cam.type = "ORTHO"
        cam.ortho_scale = ortho
    else:
        cam.lens = lens
    cam.clip_start, cam.clip_end = 5, 20000
    ob = link(bpy.data.objects.new(name, cam), coll)
    ob.location = loc
    look_at(ob, target)
    return ob


def mirror_plane():
    """実カメラ C と仮想カメラ C'（奥から俯角 e）の垂直二等分面 = 鏡の面。"""
    C = TARGET + view_dir(-1) * CAM_DIST
    Cp = TARGET + view_dir(+1) * (CAM_DIST + MIRROR_EXTRA)
    return (C + Cp) / 2, (C - Cp).normalized(), C


def build_mirror(coll, floor_z):
    M, nrm, C = mirror_plane()
    tilt = math.degrees(math.atan2(-nrm.z, -nrm.y))
    w, hgt, bw = 480.0 * SS, 520.0 * SS, 14.0 * SS
    up = Vector((0, -nrm.z, nrm.y))
    if up.z < 0:
        up = -up
    s = (floor_z + bw - M.z) / up.z
    bottom = M + up * s
    center = bottom + up * (hgt / 2)
    right = Vector((1, 0, 0))
    bm = bmesh.new()
    vs = [bm.verts.new(center + right * sx * w / 2 + up * sy * hgt / 2)
          for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    f = bm.faces.new(vs)
    f.normal_update()
    if f.normal.dot(nrm) < 0:
        f.normal_flip()
    me = bpy.data.meshes.new("Mirror")
    bm.to_mesh(me)
    bm.free()
    me.materials.append(plain("MirrorSilver", (0.80, 0.88, 0.86), 0.0, 1.0))
    mirror = link(bpy.data.objects.new("Mirror", me), coll)
    fb = bmesh.new()
    back = -nrm * 4 * SS
    for a, b in (((-1, -1), (1, -1)), ((1, -1), (1, 1)), ((1, 1), (-1, 1)), ((-1, 1), (-1, -1))):
        pa = center + right * a[0] * (w / 2 + bw / 2) + up * a[1] * (hgt / 2 + bw / 2)
        pb = center + right * b[0] * (w / 2 + bw / 2) + up * b[1] * (hgt / 2 + bw / 2)
        dd = pb - pa
        side = dd.cross(nrm).normalized() * bw / 2
        ext = dd.normalized() * bw / 2
        q = [pa - ext + side, pb + ext + side, pb + ext - side, pa - ext - side]
        vv = [fb.verts.new(v + nrm * SS) for v in q] + [fb.verts.new(v + back) for v in q]
        fb.faces.new(vv[:4])
        fb.faces.new(vv[4:][::-1])
        for k in range(4):
            fb.faces.new((vv[k], vv[(k + 1) % 4], vv[4 + (k + 1) % 4], vv[4 + k]))
    bmesh.ops.recalc_face_normals(fb, faces=list(fb.faces))
    fme = bpy.data.meshes.new("MirrorFrame")
    fb.to_mesh(fme)
    fb.free()
    fme.materials.append(plain("MirrorFrameBlack", (0.03, 0.03, 0.03), 0.4))
    mframe = link(bpy.data.objects.new("MirrorFrame", fme), coll)
    return mirror, mframe, tilt, bottom


# ---------------------------------------------------------------- シーン
def setup_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.name = "EngravedPainting"
    sc.unit_settings.system = "METRIC"
    sc.unit_settings.scale_length = 0.001
    sc.unit_settings.length_unit = "MILLIMETERS"
    sc.render.engine = "CYCLES"
    sc.cycles.samples = 32 if QUICK else 192
    sc.cycles.use_denoising = True
    sc.view_settings.view_transform = "Standard"
    sc.view_settings.look = "None"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "METAL"
        prefs.get_devices()
        for dev in prefs.devices:
            dev.use = True
        sc.cycles.device = "GPU"
    except Exception as exc:
        print("GPU unavailable:", exc)
    return sc


def build_lights_world(sc, coll):
    world = bpy.data.worlds.new("World")
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.85, 0.84, 0.81, 1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.1
    sc.world = world
    for name, sy in (("Light_Front", -1), ("Light_Back", 1)):
        L = link(bpy.data.objects.new(name, bpy.data.lights.new(name, "AREA")), coll)
        L.data.shape = "DISK"
        L.data.size = 1800
        L.data.energy = 0.9e6
        L.location = (0, sy * 700, 900)
        look_at(L, Vector((0, 0, Z0 * 0.5)))
    top = link(bpy.data.objects.new("Light_Top", bpy.data.lights.new("Light_Top", "AREA")), coll)
    top.data.size = 1200
    top.data.energy = 0.5e6
    top.location = (0, 0, 1300)
    bpy.ops.mesh.primitive_plane_add(size=6000, location=(0, 0, BOTTOM))
    table = bpy.context.active_object
    table.name = "Table"
    for c in table.users_collection:
        c.objects.unlink(table)
    coll.objects.link(table)
    table.data.materials.append(plain("TableLinen", lin("#d6cfc1"), 0.85))


def build_orbit(coll):
    pivot = link(bpy.data.objects.new("OrbitPivot", None), coll)
    pivot.location = TARGET
    cam = make_camera("Cam_Orbit", coll, TARGET + view_dir(-1) * 1500 * SS, TARGET, lens=85)
    cam.parent = pivot
    cam.matrix_parent_inverse = pivot.matrix_world.inverted()
    bpy.context.preferences.edit.keyframe_new_interpolation_type = "LINEAR"
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, ORBIT_FRAMES
    sc.render.fps = 30
    pivot.rotation_euler = (0, 0, 0)
    pivot.keyframe_insert("rotation_euler", index=2, frame=1)
    pivot.rotation_euler = (0, 0, 2 * math.pi)
    pivot.keyframe_insert("rotation_euler", index=2, frame=ORBIT_FRAMES + 1)
    sc.frame_set(1)
    return cam


def main():
    sc = setup_scene()
    art = bpy.data.collections.new("Artwork")
    stage = bpy.data.collections.new("Stage")
    cams = bpy.data.collections.new("Cameras")
    for c in (art, stage, cams):
        sc.collection.children.link(c)
    mats = [paper("Hinoki", lin("#e6d3b1"), 0.75), plain("Sumi", lin("#15120f"), 0.9)]
    block = build_block(art, mats)
    build_lights_world(sc, stage)
    mirror, mframe, tilt, mbottom = build_mirror(stage, BOTTOM)

    half = 1.3 * UNIT
    camA = make_camera("Cam_A_RedFuji", cams, TARGET + view_dir(-1) * 2000, TARGET, ortho=2 * half)
    camB = make_camera("Cam_B_Back", cams, TARGET + view_dir(+1) * 2000, TARGET, ortho=2 * half)
    M, nrm, C = mirror_plane()
    upA = Vector((0, SIN_E, COS_E))
    show = make_camera("Cam_Mirror_Showcase", cams, C, TARGET + upA * (MIRROR_EXTRA * 0.6), lens=80)
    show.data.sensor_fit = "VERTICAL"
    show.data.sensor_height = 24
    obl = make_camera("Cam_Oblique", cams, Vector((-360, -430, 300)) * SS + Vector((0, 0, Z0 * (1 - SS) * 0.8)),
                      Vector((0, 0, Z0 * 0.8)), lens=60)
    top = make_camera("Cam_Top", cams, Vector((0, 0, 1500)), Vector((0, 0, 0)), ortho=2 * (HD + BORDER + 12))
    orbit = build_orbit(cams)
    sc.camera = show

    rep = D.validate(verbose=False)
    info = dict(lines=LD.N_LINES, Z0=Z0, block_mm=(round(2 * (HW + BORDER)), round(2 * (HD + BORDER)),
                                                  round(float(max(D.Zlo.max(), D.Zhi.max())) - BOTTOM, 1)),
                relief_mm=tuple(round(v, 1) for v in rep["relief_mm"]), max_slope_y=round(rep["max_slope_y"], 3),
                min_land_mm=round(rep["min_land_mm"], 3), design_ok=rep["ok"], mirror_tilt_deg=round(tilt, 2),
                **manifold_report(block))
    print("BUILD", info)
    sc["engrave_info"] = str(info)
    bpy.ops.wm.save_as_mainfile(filepath=BLEND_OUT)

    bpy.ops.object.select_all(action="DESELECT")
    block.select_set(True)
    bpy.context.view_layer.objects.active = block
    bpy.ops.wm.stl_export(filepath=STL_OUT, export_selected_objects=True, global_scale=1.0)
    bpy.ops.object.select_all(action="DESELECT")

    if DO_RENDER:
        render_all(sc, camA, camB, show, obl, top, [mirror, mframe])
    if DO_VIDEO:
        render_video(sc, orbit, [mirror, mframe])
    sc.camera = show
    bpy.ops.wm.save_as_mainfile(filepath=BLEND_OUT)


# ---------------------------------------------------------------- レンダリング
def save_px(px, path, name="tmp"):
    h, w, _ = px.shape
    im = bpy.data.images.new(name, w, h, alpha=True)
    im.pixels.foreach_set(px.ravel())
    im.filepath_raw = path
    im.file_format = "PNG"
    im.save()
    bpy.data.images.remove(im)


def flip_png_horizontally(path):
    img = bpy.data.images.load(path, check_existing=False)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    bpy.data.images.remove(img)
    save_px(px.reshape(h, w, 4)[:, ::-1, :].copy(), path)


def contact_sheet(paths, out, cell=700):
    pad = 20
    W = 2 * cell + 3 * pad
    sheet = np.ones((W, W, 4), dtype=np.float32)
    sheet[..., :3] = 0.97
    for k, pth in enumerate(paths):
        img = bpy.data.images.load(pth, check_existing=False)
        w, h = img.size
        f = cell / max(w, h)
        img.scale(max(1, int(w * f)), max(1, int(h * f)))
        w, h = img.size
        px = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(px)
        px = px.reshape(h, w, 4)
        r, c = divmod(k, 2)
        y0 = W - (pad + r * (cell + pad)) - cell + (cell - h) // 2
        x0 = pad + c * (cell + pad) + (cell - w) // 2
        sheet[y0:y0 + h, x0:x0 + w] = px
        bpy.data.images.remove(img)
    save_px(sheet, out, "contact")


def set_lit(v):
    for m in bpy.data.materials:
        if m.node_tree:
            for n in m.node_tree.nodes:
                if n.type == "MIX_SHADER":
                    n.inputs["Fac"].default_value = v


def render_all(sc, camA, camB, show, obl, top, mirror_objs):
    os.makedirs(RENDER_DIR, exist_ok=True)
    r = sc.render
    r.image_settings.file_format = "PNG"
    base = 700 if QUICK else 2000
    jobs = [
        ("view_A_red_fuji.png", camA, (base, base), True),
        ("view_B_pearl_earring_in_mirror.png", camB, (base, base), True),
        ("mirror_showcase.png", show, (int(base * 0.75), base), False),
        ("oblique.png", obl, (int(base * 0.7), int(base * 0.525)), True),
        ("top_view.png", top, (int(base * 0.56), int(base * 0.7)), True),
    ]
    for fname, cam, (rx, ry), hide_mirror in jobs:
        for o in mirror_objs:
            o.hide_render = hide_mirror
        set_lit(LIT)
        sc.camera = cam
        r.resolution_x, r.resolution_y = rx, ry
        r.filepath = os.path.join(RENDER_DIR, fname)
        bpy.ops.render.render(write_still=True)
        if cam is camB:
            flip_png_horizontally(r.filepath)   # 奥から見た像を左右反転 = 鏡の中の像
        print("rendered", r.filepath)
    set_lit(LIT)
    for o in mirror_objs:
        o.hide_render = False
    contact_sheet([os.path.join(RENDER_DIR, j[0]) for j in jobs[:4]],
                  os.path.join(RENDER_DIR, "contact_sheet.png"))


def render_video(sc, orbit, mirror_objs):
    for o in mirror_objs:
        o.hide_render = True
    r = sc.render
    engine = r.engine
    r.engine = "BLENDER_EEVEE"
    r.resolution_x = r.resolution_y = 540 if QUICK else 720
    r.image_settings.media_type = "VIDEO"
    r.image_settings.file_format = "FFMPEG"
    r.ffmpeg.format = "MPEG4"
    r.ffmpeg.codec = "H264"
    r.ffmpeg.constant_rate_factor = "HIGH"
    r.filepath = os.path.join(RENDER_DIR, "orbit.mp4")
    sc.camera = orbit
    bpy.ops.render.render(animation=True)
    r.image_settings.media_type = "IMAGE"
    r.image_settings.file_format = "PNG"
    r.engine = engine
    for o in mirror_objs:
        o.hide_render = False
    sc.frame_set(1)
    print("rendered", r.filepath)


main()
