"""Bambu Studio のコマンドラインで Bambu Lab P1S 用にスライスし、G-code 入りの 3MF を作る（サンドボックスの外で）。

  python3 painting-03/print/slice_p1s.py <版> ...
  python3 painting-03/print/slice_p1s.py --presets-only n04_ams n02_ams   # プリセットだけ（print/presets_<名前>/）
  版：pair_raijin_n04     … 星月夜 ⇄ 雷神・0.4 mm ノズル（P1S 標準）・単色。刷ったあとで溝に墨を入れる
      pair_raijin_n04_ams … 同・AMS で溝だけ黒く刷る 2 色（色替えは溝のある上面の約 1.3 mm だけ）
      pair_raijin_n02     … 同・0.2 mm ノズル（別売）・単色（n02_ams も作れる）
      pair_fujin_…        … ローヌ川の星月夜 ⇄ 風神（同じ 4 通り）
  --presets-only の n04_ams・n02_ams は、bambu_views.py が確認用のプロジェクト 3MF を作るときに使うノズルごとの 2 色の設定。

使うシステムプリセット（~/Library/Application Support/BambuStudio/system/BBL）を inherits の根から重ね、下の上書きを足して渡す。
自動配置はせず、3MF の中で置いた位置（台の中央。板は 135.7 × 150.0 mm）のまま使う。
出力：pair/print/<名前>_<ノズル>[_ams]_P1S.3mf と、その要約 pair/print/slice_summary_<版>.txt
"""
import json
import os
import re
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BAMBU = "/Applications/BambuStudio.app/Contents/MacOS/BambuStudio"
SYS = os.path.expanduser("~/Library/Application Support/BambuStudio/system/BBL")

COMMON = {"wall_generator": "arachne",          # 溝の間の細い面（最小 0.5 mm / 0.3 mm）を 1 本の壁で出す
          "sparse_infill_density": "15%",
          "enable_support": "0",                # 上面は高さ場（どこも真上から見える形）なのでサポート不要
          "brim_type": "outer_only", "brim_width": "3"}   # 厚さ 5 mm の大きな薄板なので、反りを抑える
# ノズルごとの設定（単色と AMS 2 色）
NOZZLES = {
    "n04": dict(machine="Bambu Lab P1S 0.4 nozzle", process="0.12mm Fine @BBL X1C",
                filament="Bambu PLA Matte @BBL P1S 0.4 nozzle", over={"layer_height": "0.12"}),
    "n02": dict(machine="Bambu Lab P1S 0.2 nozzle", process="0.08mm High Quality @BBL P1P 0.2 nozzle",
                filament="Bambu PLA Matte @BBL X1C 0.2 nozzle", over={"layer_height": "0.08"}),
}
# AMS 2 色：板が台いっぱいでプライムタワーを置く場所がないので切る（パージは P1S の排出口で行われる）
AMS_OVER = {"enable_prime_tower": "0", "brim_type": "no_brim"}
COLOURS = ["#E6D3B1", "#1E1B18"]                      # 地・墨


def nozzle_variant(nz, ams, **extra):
    n = NOZZLES[nz]
    v = dict(machine=n["machine"], process=n["process"], filaments=[n["filament"]] * (2 if ams else 1),
             over=dict(n["over"], **(AMS_OVER if ams else {})), **extra)
    if ams:
        v["colours"] = COLOURS
    return v


# 2 枚組（1 枚ずつ別のファイル）：pair_raijin_…（星月夜 ⇄ 雷神）・pair_fujin_…（ローヌ川の星月夜 ⇄ 風神）
VARIANTS = {}
for _who, _name in (("raijin", "pair_starry_raijin"), ("fujin", "pair_rhone_fujin")):
    for _nz in NOZZLES:
        VARIANTS[f"pair_{_who}_{_nz}"] = nozzle_variant(_nz, False, model=f"../pair/print/{_name}_p1s_{_nz}_plain.3mf",
                                                        out=f"../pair/print/{_name}_{_nz}_P1S.3mf")
        VARIANTS[f"pair_{_who}_{_nz}_ams"] = nozzle_variant(_nz, True, model=f"../pair/{_name}_p1s_{_nz}_painted.3mf",
                                                            out=f"../pair/print/{_name}_{_nz}_ams_P1S.3mf")
PRESET_SETS = {f"{nz}_ams": nozzle_variant(nz, True) for nz in NOZZLES}   # --presets-only 用（確認用プロジェクトの設定）
PRESETS_ONLY = "--presets-only" in sys.argv   # プリセットだけ書き出す（bambu_views.py が確認用のプロジェクト 3MF に使う）


def flatten(kind, name):
    chain = []
    while name:
        with open(os.path.join(SYS, kind, name + ".json"), encoding="utf-8") as f:
            j = json.load(f)
        chain.append(j)
        name = j.get("inherits")
    out = {}
    for j in reversed(chain):
        out.update(j)
    out.pop("inherits", None)
    return out


def slice_variant(key):
    v = VARIANTS.get(key) or PRESET_SETS[key]
    out = os.path.normpath(os.path.join(HERE, v["out"])) if "out" in v else None
    tmp = os.path.join(HERE, "presets_" + key)
    os.makedirs(tmp, exist_ok=True)
    m = flatten("machine", v["machine"])
    p = flatten("process", v["process"])
    p.update(COMMON)
    p.update(v["over"])
    p["name"] = v["process"] + " 星月夜⇄風神雷神"
    for cfg in (p,):                                   # P1P 用の工程を P1S でも使えるように、対応機種へ加える
        if v["machine"] not in cfg.get("compatible_printers", [v["machine"]]):
            cfg["compatible_printers"] = cfg["compatible_printers"] + [v["machine"]]
    paths = {"machine": os.path.join(tmp, "machine.json"), "process": os.path.join(tmp, "process.json")}
    json.dump(m, open(paths["machine"], "w"), ensure_ascii=False, indent=1)
    json.dump(p, open(paths["process"], "w"), ensure_ascii=False, indent=1)
    fil = []
    for i, name in enumerate(v["filaments"]):
        f = flatten("filament", name)
        if v["machine"] not in f.get("compatible_printers", [v["machine"]]):
            f["compatible_printers"] = f["compatible_printers"] + [v["machine"]]
        if "colours" in v:
            f["filament_colour"] = [v["colours"][i]]
            f["name"] = name + (" (地)" if i == 0 else " (墨)")
        fp = os.path.join(tmp, f"filament_{i + 1}.json")
        json.dump(f, open(fp, "w"), ensure_ascii=False, indent=1)
        fil.append(fp)
    if PRESETS_ONLY:
        print("プリセット:", tmp)
        return
    cmd = [BAMBU, "--orient", "0", "--arrange", "0", "--slice", "0",
           "--load-settings", paths["machine"] + ";" + paths["process"],
           "--load-filaments", ";".join(fil), "--export-3mf", out, os.path.join(HERE, v["model"])]
    r = subprocess.run(cmd, capture_output=True, text=True)
    log = r.stdout + r.stderr
    open(os.path.join(tmp, "slice.log"), "w").write(log)
    if r.returncode != 0 or not os.path.exists(out):
        print(log[-3000:])
        sys.exit(f"{key}: スライスに失敗しました（終了コード {r.returncode}）")
    summarize(key, out, log)


def summarize(key, out, log):
    with zipfile.ZipFile(out) as z:
        info = z.read("Metadata/slice_info.config").decode()
        gcode = [n for n in z.namelist() if n.endswith(".gcode")]
    lines = [f"3MF: {os.path.basename(out)}", f"G-code: {', '.join(gcode)}"]
    pred = re.search(r'key="prediction" value="(\d+)"', info)
    if pred:
        s = int(pred.group(1))
        lines.append(f"造形時間の予測: {s // 3600} 時間 {s % 3600 // 60} 分")
    for fm in re.finditer(r'<filament id="(\d+)"[^>]*used_m="([\d.]+)" used_g="([\d.]+)"', info):
        lines.append(f"フィラメント {fm.group(1)}: {float(fm.group(3)):.0f} g（{float(fm.group(2)):.1f} m）")
    warns = re.findall(r'<warning[^>]*msg="([^"]*)"', info)
    lines.append("スライスの警告: " + ("; ".join(warns) if warns else "なし"))
    text = "\n".join(lines)
    print(text, flush=True)
    open(os.path.join(os.path.dirname(out), f"slice_summary_{key}.txt"), "w").write(text + "\n")


if __name__ == "__main__":
    for k in [a for a in sys.argv[1:] if not a.startswith("--")] or ["pair_raijin_n04"]:
        slice_variant(k)
