"""線刻の変身画・おまけの 2 枚組を 1 枚ずつ Blender で組み立てる（painting-01/blender/build_lines.py と同じ構成）。

design/design.py の設計から、STL と同じ板（溝の面は墨、ほかは地の色）を作り、鏡・照明・カメラを置いて .blend を保存する。
  - カメラ：手前（俯角 45°・星月夜）、奥（俯角 45°。描いた像を左右反転すると鏡の中の雷神・風神）、
            鏡を入れた展示写真、斜め、真上、周回
  - 鏡は板の奥に、手前のカメラから見て奥の俯角 45° の像が映る向きに立てる
  - 塗りは地と墨の 2 つだけ。どちらから見ても同じ（見る向きによる塗り分けはしない）

実行（illusion-works/ から。GPU 検出のためサンドボックスの外で）:
  /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup \\
      --python painting-03/blender/build_blend.py -- [--profile pair_raijin_n04|pair_fujin_n04|…_n02] [--render] [--quick] [--video]
出力：pair/pair_starry_raijin_p1s_<ノズル>.blend・pair/pair_rhone_fujin_p1s_<ノズル>.blend、--render で pair/renders_<名前>_p1s_<ノズル>/
"""
import math
import os
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                      # painting-03/
sys.path.insert(0, os.path.join(ROOT, "design"))
import design as DS  # noqa: E402

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
PROFILE = args[args.index("--profile") + 1] if "--profile" in args else "pair_raijin_n04"
DO_RENDER, QUICK, DO_VIDEO = "--render" in args, "--quick" in args, "--video" in args
P = DS.PROFILES[PROFILE]
NAME, NZ = P["NAME"], P["NZ"]                               # 1 枚ずつ別の .blend を pair/ に書き出す
BLEND_OUT = os.path.join(DS.OUT_DIR, f"{NAME}_p1s_{NZ}.blend")
RENDER_DIR = os.path.join(DS.OUT_DIR, f"renders_{NAME}_p1s_{NZ}")

D = DS.Design(P)
SIN_E, COS_E = DS.SIN_E, DS.COS_E
Z0 = D.Z0
HW, HD = D.W / 2, D.HD                            # 絵の部分の半幅・半奥行き [mm]
BORDER = D.p["BORDER"]
ORBIT_FRAMES = 240
SC = D.H / 162.0                                  # シーンの縮尺（カメラ・鏡・照明は、絵の高さ 162 mm の板に合わせて決めた値を縮める）
CAM_DIST = 3000.0 * SC
MIRROR_EXTRA = 340.0 * SC
TARGET = Vector((0, 0, Z0))


# ---------------------------------------------------------------- 材質
def lin(hexcol):
    h = hexcol.lstrip("#")
    f = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return tuple(f(int(h[i:i + 2], 16) / 255) for i in (0, 2, 4))


def plain(name, rgb, rough=0.6, metallic=0.0):
    m = bpy.data.materials.new(name)
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metallic
    m.diffuse_color = (*rgb, 1)
    return m


def link(ob, coll):
    coll.objects.link(ob)
    return ob


# ---------------------------------------------------------------- 板
def build_block(coll, materials):
    V, T, INKF = D.mesh()
    me = bpy.data.meshes.new("EngravedBlock")
    me.vertices.add(len(V))
    me.vertices.foreach_set("co", V.astype(np.float32).ravel())
    me.loops.add(3 * len(T))
    me.loops.foreach_set("vertex_index", T.astype(np.int32).ravel())
    me.polygons.add(len(T))
    me.polygons.foreach_set("loop_start", np.arange(0, 3 * len(T), 3, dtype=np.int32))
    me.update(calc_edges=True)
    for m in materials:
        me.materials.append(m)
    me.polygons.foreach_set("material_index", INKF.astype(np.int32))
    me.validate()
    ob = link(bpy.data.objects.new("EngravedBlock", me), coll)
    bm = bmesh.new()
    bm.from_mesh(me)
    nm = sum(1 for e in bm.edges if not e.is_manifold)
    info = dict(verts=len(bm.verts), tris=len(bm.faces), non_manifold_edges=nm)
    bm.free()
    return ob, info


# ---------------------------------------------------------------- 視点・鏡
def view_dir(sign):
    return Vector((0, sign * COS_E, SIN_E))


def look_at(ob, target):
    ob.rotation_euler = (target - ob.location).to_track_quat("-Z", "Y").to_euler()


def make_camera(name, coll, loc, target, ortho=None, lens=50):
    cam = bpy.data.cameras.new(name)
    if ortho:
        cam.type = "ORTHO"
        cam.ortho_scale = ortho
    else:
        cam.lens = lens
    cam.clip_start, cam.clip_end = 5, 20000
    ob = link(bpy.data.objects.new(name, cam), coll)
    ob.location = loc
    look_at(ob, target)
    return ob


def mirror_plane():
    """実カメラ C と仮想カメラ C'（奥から俯角 e）の垂直二等分面 = 鏡の面。"""
    C = TARGET + view_dir(-1) * CAM_DIST
    Cp = TARGET + view_dir(+1) * (CAM_DIST + MIRROR_EXTRA)
    return (C + Cp) / 2, (C - Cp).normalized(), C


def build_mirror(coll):
    M, nrm, C = mirror_plane()
    tilt = math.degrees(math.atan2(-nrm.z, -nrm.y))
    w, hgt, bw = 520.0 * SC, 520.0 * SC, 14.0 * SC
    up = Vector((0, -nrm.z, nrm.y))
    if up.z < 0:
        up = -up
    s = (bw - M.z) / up.z
    center = M + up * s + up * (hgt / 2)
    right = Vector((1, 0, 0))
    bm = bmesh.new()
    vs = [bm.verts.new(center + right * sx * w / 2 + up * sy * hgt / 2) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    f = bm.faces.new(vs)
    f.normal_update()
    if f.normal.dot(nrm) < 0:
        f.normal_flip()
    me = bpy.data.meshes.new("Mirror")
    bm.to_mesh(me)
    bm.free()
    me.materials.append(plain("MirrorSilver", (0.80, 0.88, 0.86), 0.0, 1.0))
    mirror = link(bpy.data.objects.new("Mirror", me), coll)
    fb = bmesh.new()
    back = -nrm * 4
    for a, b in (((-1, -1), (1, -1)), ((1, -1), (1, 1)), ((1, 1), (-1, 1)), ((-1, 1), (-1, -1))):
        pa = center + right * a[0] * (w / 2 + bw / 2) + up * a[1] * (hgt / 2 + bw / 2)
        pb = center + right * b[0] * (w / 2 + bw / 2) + up * b[1] * (hgt / 2 + bw / 2)
        dd = pb - pa
        side = dd.cross(nrm).normalized() * bw / 2
        ext = dd.normalized() * bw / 2
        q = [pa - ext + side, pb + ext + side, pb + ext - side, pa - ext - side]
        vv = [fb.verts.new(v + nrm * 1.0) for v in q] + [fb.verts.new(v + back) for v in q]
        fb.faces.new(vv[:4])
        fb.faces.new(vv[4:][::-1])
        for k in range(4):
            fb.faces.new((vv[k], vv[(k + 1) % 4], vv[4 + (k + 1) % 4], vv[4 + k]))
    bmesh.ops.recalc_face_normals(fb, faces=list(fb.faces))
    fme = bpy.data.meshes.new("MirrorFrame")
    fb.to_mesh(fme)
    fb.free()
    fme.materials.append(plain("MirrorFrameBlack", (0.03, 0.03, 0.03), 0.4))
    return mirror, link(bpy.data.objects.new("MirrorFrame", fme), coll), tilt


# ---------------------------------------------------------------- シーン
def setup_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.name = "StarryFujin"
    sc.unit_settings.system = "METRIC"
    sc.unit_settings.scale_length = 0.001
    sc.unit_settings.length_unit = "MILLIMETERS"
    sc.render.engine = "CYCLES"
    sc.cycles.samples = 32 if QUICK else 160
    sc.cycles.use_denoising = True
    sc.view_settings.view_transform = "Standard"
    sc.view_settings.look = "None"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "METAL"
        prefs.get_devices()
        for dev in prefs.devices:
            dev.use = True
        sc.cycles.device = "GPU"
    except Exception as exc:
        print("GPU unavailable:", exc)
    return sc


def build_lights_world(sc, coll):
    world = bpy.data.worlds.new("World")
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.85, 0.84, 0.81, 1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.1
    sc.world = world
    for name, sy in (("Light_Front", -1), ("Light_Back", 1)):          # 手前と奥に均等に、上からやわらかく
        L = link(bpy.data.objects.new(name, bpy.data.lights.new(name, "AREA")), coll)
        L.data.shape = "DISK"
        L.data.size = 1800 * SC
        L.data.energy = 0.9e6 * SC ** 2
        L.location = (0, sy * 700 * SC, 900 * SC)
        look_at(L, Vector((0, 0, Z0 * 0.5)))
    top = link(bpy.data.objects.new("Light_Top", bpy.data.lights.new("Light_Top", "AREA")), coll)
    top.data.size = 1200 * SC
    top.data.energy = 0.5e6 * SC ** 2
    top.location = (0, 0, 1300 * SC)
    bpy.ops.mesh.primitive_plane_add(size=6000, location=(0, 0, 0))
    table = bpy.context.active_object
    table.name = "Table"
    for c in table.users_collection:
        c.objects.unlink(table)
    coll.objects.link(table)
    table.data.materials.append(plain("TableLinen", lin("#d6cfc1"), 0.85))


def build_orbit(coll):
    pivot = link(bpy.data.objects.new("OrbitPivot", None), coll)
    pivot.location = TARGET
    cam = make_camera("Cam_Orbit", coll, TARGET + view_dir(-1) * 1500 * SC, TARGET, lens=70)
    cam.parent = pivot
    cam.matrix_parent_inverse = pivot.matrix_world.inverted()
    bpy.context.preferences.edit.keyframe_new_interpolation_type = "LINEAR"
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, ORBIT_FRAMES
    sc.render.fps = 30
    pivot.rotation_euler = (0, 0, 0)
    pivot.keyframe_insert("rotation_euler", index=2, frame=1)
    pivot.rotation_euler = (0, 0, 2 * math.pi)
    pivot.keyframe_insert("rotation_euler", index=2, frame=ORBIT_FRAMES + 1)
    sc.frame_set(1)
    return cam


# ---------------------------------------------------------------- レンダリング
def save_px(px, path, name="tmp"):
    h, w, _ = px.shape
    im = bpy.data.images.new(name, w, h, alpha=True)
    im.pixels.foreach_set(px.ravel())
    im.filepath_raw = path
    im.file_format = "PNG"
    im.save()
    bpy.data.images.remove(im)


def flip_png_horizontally(path):
    img = bpy.data.images.load(path, check_existing=False)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    bpy.data.images.remove(img)
    save_px(px.reshape(h, w, 4)[:, ::-1, :].copy(), path)


def contact_sheet(paths, out, cell=900):
    """2 × 2 に並べる（左上：手前、右上：鏡の中、左下：展示写真、右下：斜め）。"""
    pad = 20
    W, Hs = 2 * cell + 3 * pad, 2 * cell + 3 * pad
    sheet = np.ones((Hs, W, 4), dtype=np.float32)
    sheet[..., :3] = 0.97
    for k, pth in enumerate(paths):
        img = bpy.data.images.load(pth, check_existing=False)
        w, h = img.size
        f = cell / max(w, h)
        img.scale(max(1, int(w * f)), max(1, int(h * f)))
        w, h = img.size
        px = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(px)
        r, c = divmod(k, 2)
        y0 = Hs - (pad + r * (cell + pad)) - cell + (cell - h) // 2
        x0 = pad + c * (cell + pad) + (cell - w) // 2
        sheet[y0:y0 + h, x0:x0 + w] = px.reshape(h, w, 4)
        bpy.data.images.remove(img)
    save_px(sheet, out, "contact")


def render_all(sc, camA, camB, show, obl, top, mirror_objs):
    os.makedirs(RENDER_DIR, exist_ok=True)
    r = sc.render
    r.image_settings.file_format = "PNG"
    base = 700 if QUICK else 2000
    asp = D.aspect
    jobs = [
        (f"view_A_{D.paint['A']}.png", camA, (base, int(base / asp * 1.05)), True),
        (f"view_B_{D.paint['B']}_in_mirror.png", camB, (base, int(base / asp * 1.05)), True),
        ("mirror_showcase.png", show, (int(base * 0.75), base), False),
        ("oblique.png", obl, (base, int(base * 0.7)), True),
        ("top_view.png", top, (base, int(base * (HD + BORDER + 12) / (HW + BORDER + 12))), True),
    ]
    for fname, cam, (rx, ry), hide_mirror in jobs:
        for o in mirror_objs:
            o.hide_render = hide_mirror
        sc.camera = cam
        r.resolution_x, r.resolution_y = rx, ry
        r.filepath = os.path.join(RENDER_DIR, fname)
        bpy.ops.render.render(write_still=True)
        if cam is camB:
            flip_png_horizontally(r.filepath)   # 奥から見た像を左右反転 = 鏡の中の像
        print("rendered", r.filepath, flush=True)
    for o in mirror_objs:
        o.hide_render = False
    contact_sheet([os.path.join(RENDER_DIR, j[0]) for j in jobs[:4]], os.path.join(RENDER_DIR, "contact_sheet.png"))


def render_video(sc, orbit, mirror_objs):
    for o in mirror_objs:
        o.hide_render = True
    r = sc.render
    engine = r.engine
    r.engine = "BLENDER_EEVEE"
    r.resolution_x = r.resolution_y = 540 if QUICK else 720
    r.image_settings.media_type = "VIDEO"
    r.image_settings.file_format = "FFMPEG"
    r.ffmpeg.format = "MPEG4"
    r.ffmpeg.codec = "H264"
    r.ffmpeg.constant_rate_factor = "HIGH"
    r.filepath = os.path.join(RENDER_DIR, "orbit.mp4")
    sc.camera = orbit
    bpy.ops.render.render(animation=True)
    r.image_settings.media_type = "IMAGE"
    r.image_settings.file_format = "PNG"
    r.engine = engine
    for o in mirror_objs:
        o.hide_render = False
    sc.frame_set(1)
    print("rendered", r.filepath)


def main():
    sc = setup_scene()
    art = bpy.data.collections.new("Artwork")
    stage = bpy.data.collections.new("Stage")
    cams = bpy.data.collections.new("Cameras")
    for c in (art, stage, cams):
        sc.collection.children.link(c)
    mats = [plain("Ji", lin("#e6d3b1"), 0.75), plain("Sumi", lin("#15120f"), 0.9)]   # 地（確認用 3MF と同じ色）と墨
    block, info = build_block(art, mats)
    build_lights_world(sc, stage)
    mirror, mframe, tilt = build_mirror(stage)

    half = 1.08 * HW
    camA = make_camera("Cam_A_StarryNight", cams, TARGET + view_dir(-1) * 2000, TARGET, ortho=2 * half)
    camB = make_camera("Cam_B_Back", cams, TARGET + view_dir(+1) * 2000, TARGET, ortho=2 * half)
    M, nrm, C = mirror_plane()
    upA = Vector((0, SIN_E, COS_E))
    show = make_camera("Cam_Mirror_Showcase", cams, C, TARGET + upA * (MIRROR_EXTRA * 0.55), lens=125)
    show.data.sensor_fit = "VERTICAL"
    show.data.sensor_height = 24
    obl = make_camera("Cam_Oblique", cams, Vector((-380, -460, 320)) * SC, Vector((0, 0, Z0 * 0.8)), lens=55)
    top = make_camera("Cam_Top", cams, Vector((0, 0, 1500)), Vector((0, 0, 0)), ortho=2 * (HW + BORDER + 12))
    orbit = build_orbit(cams)
    sc.camera = show

    rep = D.validate()
    info.update(profile=PROFILE, lines=D.N, Z0=round(Z0, 2), size_mm=tuple(round(v, 1) for v in rep["size_mm"]),
                min_land_mm=round(rep["min_land_mm"], 3), design_ok=rep["ok"], mirror_tilt_deg=round(tilt, 2))
    print("BUILD", info, flush=True)
    sc["pair_info"] = str(info)
    bpy.ops.wm.save_as_mainfile(filepath=BLEND_OUT)
    if DO_RENDER:
        render_all(sc, camA, camB, show, obl, top, [mirror, mframe])
    if DO_VIDEO:
        render_video(sc, orbit, [mirror, mframe])
    sc.camera = show
    bpy.ops.wm.save_as_mainfile(filepath=BLEND_OUT)


main()
