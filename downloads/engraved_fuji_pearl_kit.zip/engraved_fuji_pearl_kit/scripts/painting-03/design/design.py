"""線刻の変身画・おまけの 2 枚組「星月夜 ⇄ 雷神」「ローヌ川の星月夜 ⇄ 風神」の設計と、STL・確認用 3MF の書き出し（numpy だけで動く）。

1 枚ずつ、板の上面に左右いっぱいの溝を等間隔に彫る。手前から俯角 45° で見るとゴッホの星月夜（または「ローヌ川の星月夜」）、
奥に立てた鏡の中では俵屋宗達「風神雷神図屏風」の雷神（または風神）が見える。塗りは地の色と溝の中の墨（黒）だけで、どちらから見ても同じ。
2 枚を左（星月夜 ⇄ 雷神）・右（ローヌ川 ⇄ 風神）に並べると、鏡の中は元の屏風と同じ並び（左に雷神、右に風神）になる。

しくみ（杉原厚吉「変身立体」、painting-01 と同じ式）
  面上の点を手前 A と奥 B から同じ俯角 e で見ると、左右の位置 x は共通で、上下の位置だけが変わる。
      vA =  y sin e + (z − Z0) cos e,   vB = −y sin e + (z − Z0) cos e
  溝の縁 1 本ごとに 2 つの像での位置 (vA, vB) を別々に決めれば、縁の空間曲線は一意に決まる。
      y = (vA − vB) / (2 sin e),   z = Z0 + (vA + vB) / (2 cos e)

絵の描き方（painting-02/private の「透けを消す」版と同じ方式）
  - 溝の中心は等間隔（起伏なし）。明暗は、溝の間の面の「見かけの幅」だけで描く（面の割合が大きいほど明るい）。
  - 面 1 枚ごとに、手前での見かけの幅 gA と鏡での見かけの幅 gB を別々に決める。面の縁の高さが少し変わるだけで、
    片方の像の幅は、もう一方の像に映らない。
  - Bambu Studio の照明（目に固定した平行光）では、面の明るさが面の傾き t = (gA − gB)/(gA + gB) で変わる。
    両方の像の明るさの式を連立で解き、傾きの陰影まで打ち消す（もう一方の絵が透けない）。
  - 面の割合の範囲は、どの組み合わせでも「溝の幅」「面の幅」がノズルの下限を割らない範囲に固定する。

使い方
  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/design/design.py <版> [--lines N] [--nx NX]
      [--probe A|B|AB] [--no-mesh] [--tag 名前]
  版：pair_raijin_n04（星月夜 ⇄ 雷神、既定）・pair_fujin_n04（ローヌ川の星月夜 ⇄ 風神）。0.2 mm ノズル版は末尾を _n02 に。
  出力は painting-03/pair/ の STL・確認用 3MF、pair/print/ の塗りなし 3MF、design/views/ の再現画像。
"""
import math
import os
import struct
import sys
import zipfile
import zlib

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(HERE, "source")

E = math.radians(45.0)
SIN_E, COS_E = math.sin(E), math.cos(E)
ASPECT = 1.27                     # 額の横 / 縦（見かけ。prepare.py の PAIR_ASPECT と同じ。4 枚の絵がどれも 1.26〜1.29）

# 版ごとの設定（1 枚ずつ）
#   H：絵の見かけの高さ [mm]（横は H × ASPECT）。上面の奥行きは H / sin 45° になる。
#      板の長辺（奥行き）H / sin 45° + 2 × BORDER を 150 mm にする（H = 98.99 mm。最初の版は 240 mm 以内の H = 162 mm）
#   GROOVE_W / LAND_MIN：溝の幅・溝の間の面の幅の下限 [mm]（平面上）。GROOVE_D：溝の深さ
#   N：溝の本数。溝の間隔は 162 mm の版と同じ（1.92 mm / 1.16 mm）にして、本数を減らす（間隔を詰めると濃淡の幅が狭まる）。
#   NX：左右の分割数（Bambu Studio で細部が見えるよう、0.2 mm 刻み）
#   A / B：手前の像・鏡の中の像の絵（source/<名前>.npy）、NAME：出力ファイル名の頭、NZ：ノズル
#   UVIEW：手前・鏡それぞれの、溝の間の面の見かけの幅の範囲（線の間隔に対する割合）。solve() の説明を参照。
#     18〜82 % は、透けを増やさずに濃淡を広げられる上限の目安（再現で透け 1.2〜1.4 %、明暗の比 1.7 → 2.1）。
#     外すと、どの組み合わせでも下限を割らない 26〜74 %（0.4 mm 版）に固定する前の方式になる
#   板の外形は 136 × 150 mm。P1S の台の左手前の使えない区画（18 × 28 mm）にはかからないので、台の中央に置く（BED_X）
PROFILES = {}
for _nz, _n, _gw, _lm, _gd in (("n04", 73, 0.5, 0.5, 1.0), ("n02", 121, 0.35, 0.3, 0.8)):
    for _who, _a, _name in (("raijin", "sn_pair", "pair_starry_raijin"), ("fujin", "rhone", "pair_rhone_fujin")):
        PROFILES[f"pair_{_who}_{_nz}"] = dict(H=98.99, N=_n, NX=629, GROOVE_W=_gw, LAND_MIN=_lm, GROOVE_D=_gd, BORDER=5.0,
                                             BASE=3.5, NAME=_name, A=_a, B=_who, NZ=_nz, UVIEW=(0.18, 0.82))
OUT_DIR = os.path.join(ROOT, "pair")

# 絵ごとの明暗の作り方
#   W：RGB の重み（sRGB のまま掛ける）、LOCAL：局所的な明暗の差を強める倍率、GAMMA：暗さ t に掛けるべき、
#   EQ：明暗のヒストグラムを均す割合（0〜1。中間調に固まった絵の明暗を、使える幅いっぱいに広げる）
#   CALM：地の色に近い所の明るさを一様に寄せる強さ（風神雷神の金地の余白を静かに保つ。金箔の格子や擦れを消す）。
#   CALM_R：地の色からの色の距離の許容幅、CALM_P：寄せ方の強さ（小さいほど、許容幅の端まで強く寄せる）
#   PRE：明暗を作る前にかけるぼかし [画素]（厚塗りの筆のざらつきを抑える）
#   星月夜（sn_pair）・ローヌ川の星月夜（rhone）：黄（星・月・ガス灯とその映り込み）を明るく、青を暗く見る。
#     ローヌ川は厚塗りの筆のざらつきが強いので、先に 2.5 画素ぼかす（星・ガス灯の映り込み・舟・二人が残る）
#   風神・雷神：青を重く見る（金地は中間、白い雷神と白い布は明るく、緑の風神・紺の布・墨の雲は暗い）。
#     風神は、屏風の縁の色の淡い金地（縦の帯）も一様に寄せる。雷神は白い体が金地に沈まないよう、許容幅を狭くする
PAINTS = {
    "sn_pair": dict(W=(0.45, 0.45, 0.10), LOCAL=0.8, GAMMA=1.0, EQ=0.5),
    "rhone": dict(W=(0.5, 0.5, 0.0), PRE=2.5, LOCAL=0.6, GAMMA=1.0, EQ=0.6),
    "fujin": dict(W=(0.10, 0.35, 0.55), LOCAL=0.6, GAMMA=1.0, EQ=0.0, CALM=1.0, CALM_R=0.6, CALM_P=0.4),
    "raijin": dict(W=(0.10, 0.35, 0.55), LOCAL=0.6, GAMMA=1.0, EQ=0.0, CALM=1.0, CALM_R=0.4),
}

# Bambu Studio 2.x の照明（resources/shaders/140/mm_gouraud_wireframe.fs と同じ。painting-02/private/bambu_light.py）
LIGHT_TOP = np.array([-0.4574957, 0.4574957, 0.7624929])
LIGHT_FRONT = np.array([0.6985074, 0.1397015, 0.6985074])
WOOD = np.array([0xE6, 0xD3, 0xB1]) / 255          # 地の色（確認用 3MF の 1 番目のフィラメント）
INK = np.array([0x1E, 0x1B, 0x18]) / 255           # 溝の色（2 番目のフィラメント）
LUM = np.array([0.2126, 0.7152, 0.0722])
BED_X, BED_Y = 128.0, 128.0                        # 板の中心を置く台の上の位置 [mm]（台の中央。左手前の使えない区画 0〜18 × 0〜28 mm から十分離れる）
INK_L = float(INK @ LUM) * 0.65                    # 溝の中（底と奥の壁）の輝度の目安


# =====================================================================
#  画像の小道具
# =====================================================================

def _gauss(sigma):
    r = int(3 * sigma) + 1
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / max(sigma, 1e-3)) ** 2)
    return k / k.sum()


def blur(a, sv, sx):
    """縦 sv・横 sx 画素のガウスぼかし（端は延長）。"""
    for ax, s in ((0, sv), (1, sx)):
        if s <= 0.01:
            continue
        k = _gauss(s)
        pad = [(0, 0)] * a.ndim
        pad[ax] = (len(k) // 2, len(k) // 2)
        p = np.pad(a, pad, mode="edge")
        a = np.apply_along_axis(lambda c: np.convolve(c, k, "valid"), ax, p)
    return a


def write_png(path, img):
    a = (np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8)
    if a.ndim == 2:
        a = np.repeat(a[..., None], 3, 2)
    h, w, _ = a.shape
    raw = b"".join(b"\x00" + a[i].tobytes() for i in range(h))

    def chunk(t, dd):
        c = struct.pack(">I", len(dd)) + t + dd
        return c + struct.pack(">I", zlib.crc32(t + dd) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)


def tone(name):
    """絵の暗さ t（0 = 最も明るい … 1 = 最も暗い）[rows, cols]。上の行が絵の上。"""
    p = PAINTS[name]
    rgb = np.load(os.path.join(SRC, name + ".npy"))
    lum = rgb @ np.array(p["W"], np.float32)
    if p.get("PRE", 0) > 0:                               # 厚塗りの筆のざらつきを先に軽くぼかす（ローヌ川の星月夜）
        lum = blur(lum, p["PRE"], p["PRE"])
    if p.get("CALM", 0) > 0:
        # 余白を静かにする：地の色（金地）に近い画素の明るさを、地の代表の明るさへ寄せる。
        # 金箔の継ぎ目の格子や擦れが消え、雲・神・布（地と色が離れている）はそのまま残る
        sat = rgb.max(2) - rgb.min(2)
        cand = (rgb[..., 0] > rgb[..., 2] + 0.25) & (sat > 0.3) & (rgb[..., 0] > 0.6)
        ref = np.median(rgb[cand], axis=0)
        dist = np.linalg.norm(rgb - ref, axis=2)
        m = np.clip(1 - dist / p.get("CALM_R", 0.28), 0, 1) ** p.get("CALM_P", 0.7)
        m = blur(m, 1.5, 1.5)
        lum = lum * (1 - p["CALM"] * m) + float(np.array(p["W"]) @ ref) * p["CALM"] * m
    if p["LOCAL"] > 0:
        lum = lum + p["LOCAL"] * (lum - blur(lum, 30.0, 30.0))
    lo, hi = np.percentile(lum, 1.0), np.percentile(lum, 99.0)
    t = 1 - np.clip((lum - lo) / (hi - lo), 0, 1)
    if p.get("EQ", 0) > 0:
        rank = np.argsort(np.argsort(t.ravel())).reshape(t.shape) / (t.size - 1)
        t = (1 - p["EQ"]) * t + p["EQ"] * rank
    return t ** p["GAMMA"]


# =====================================================================
#  Bambu Studio の照明
# =====================================================================

def intensity(n):
    """目の座標の単位法線 → (拡散の強さ, 鏡面の強さ)。"""
    top = np.maximum(n @ LIGHT_TOP, 0)
    front = np.maximum(n @ LIGHT_FRONT, 0)
    diff = 0.3 + 0.8 * 0.6 * top + 0.3 * 0.6 * front
    rz = -LIGHT_TOP[2] + 2 * top * n[..., 2]
    return diff, 0.125 * 0.6 * np.maximum(rz, 0) ** 20


def to_eye(n):
    """世界座標の法線 → 俯角 E で手前から見る目の座標。"""
    return np.stack([n[..., 0], n[..., 1] * SIN_E + n[..., 2] * COS_E, -n[..., 1] * COS_E + n[..., 2] * SIN_E], -1)


def land_I(t, view):
    """奥行き方向の傾き t（dz/dy）の地の面の、視点 view での輝度。鏡の中（B）は 180° 回した向きなので t → −t。"""
    t = np.asarray(t, float) * (1 if view == "A" else -1)
    n = np.stack([np.zeros_like(t), -t, np.ones_like(t)], -1) / np.sqrt(1 + t ** 2)[..., None]
    d, sp = intensity(to_eye(n))
    return np.clip(WOOD * d[..., None] + sp[..., None], 0, 1) @ LUM


# =====================================================================
#  設計
# =====================================================================

class Design:
    def __init__(self, prof, probe=""):
        self.p = p = dict(prof)
        self.H, self.N, self.NX = p["H"], p["N"], p["NX"]
        self.aspect = ASPECT
        self.W = self.H * self.aspect
        self.paint = {"A": p["A"], "B": p["B"]}
        self.HD = self.H / 2 / SIN_E                      # 絵の部分の半奥行き（平面上）
        self.x = np.linspace(-self.W / 2, self.W / 2, self.NX)
        P = self.P = self.H / self.N                       # 溝の間隔（見かけ）
        Hh = self.H / 2
        A = -Hh + (np.arange(self.N) + 0.5) * P            # 溝 i の中心（手前の像、下から）
        self.A, self.B = A, -A                             # 鏡の像では並びが逆（手前の溝が上に映る）
        pp = P / SIN_E                                     # 溝の間隔（平面上）… 平面上の幅 = (見かけの幅の和) / (2 sin e)
        # 面の割合 u（見かけの面の幅 / 間隔）の範囲：面 (gA + gB)/(2 sin) >= LAND_MIN、溝 >= GROOVE_W がどの組でも成り立つ
        self.umin = p["LAND_MIN"] / pp
        self.umax = 1 - p["GROOVE_W"] / pp
        if self.umin >= self.umax:
            raise SystemExit(f"溝 {self.N} 本では、溝と面の下限を両立できません（間隔 {pp:.2f} mm）")
        self.probe = probe
        self.tol = p.get("TOL", 0.01)
        self.solve()
        self.build_edges()

    def sample(self, name, v):
        """絵 name の暗さを、各面の位置（列 x、見かけの高さ v [mm]）で読む。縦は面の間隔ほどにぼかしてから読む。"""
        if name[0] in self.probe:
            return np.full((len(v), self.NX), 0.5)
        T = tone(self.paint[name[0]])
        rows, cols = T.shape
        px = self.H / rows                                   # 1 画素 [mm]
        T = blur(T, 0.45 * self.P / px, max(0.6, 0.15 / px))
        r = (self.H / 2 - v) / self.H * rows - 0.5
        c = (self.x + self.W / 2) / self.W * cols - 0.5
        r0 = np.clip(np.floor(r).astype(int), 0, rows - 2)
        fr = np.clip(r - r0, 0, 1)[:, None]
        c0 = np.clip(np.floor(c).astype(int), 0, cols - 2)
        fc = np.clip(c - c0, 0, 1)[None, :]
        g = lambda rr, cc: T[rr][:, cc]
        top = g(r0, c0) * (1 - fc) + g(r0, c0 + 1) * fc
        bot = g(r0 + 1, c0) * (1 - fc) + g(r0 + 1, c0 + 1) * fc
        return top * (1 - fr) + bot * fr

    def lum(self, uA, uB, view):
        t = (uA - uB) / (uA + uB)
        u = uA if view == "A" else uB
        return u * land_I(t, view) + (1 - u) * INK_L

    def solve(self):
        """面ごとの見かけの幅の割合 (uA, uB) を、両方の像の明るさが狙いどおりになるように連立で解く。
        UVIEW が無ければ、uA・uB をそれぞれ [umin, umax] に固定する（どの組み合わせでも溝・面の下限を割らない。透けが最も少ない）。
        UVIEW = (lo, hi) なら、uA・uB をそれぞれ [lo, hi] の広い範囲で決め、制約は
            面の平面上の幅：その面の平均 s = (uA + uB)/2 ≥ umin
            溝の平面上の幅：隣り合う 2 つの面の平均 (s[i-1] + s[i])/2 ≤ umax（端の溝は s ≤ umax）
            面の奥行き方向の傾き |uA − uB|/(uA + uB) ≤ SLOPE_U
        だけにする。片方の像だけが明るい（暗い）所では、その像の幅を広く取れるので濃淡がはっきりする。
        制約に当たった所は、はみ出した分を両方の像に等しく配って直す（そこだけ、もう一方の絵がわずかに透ける）。"""
        umin, umax = self.umin, self.umax
        lo, hi = self.p.get("UVIEW", (umin, umax))
        wide = "UVIEW" in self.p
        ub = np.linspace(lo, hi, 201)
        full = lambda v: np.full_like(ub, v)
        if wide:       # 狙いの明るさの範囲：その像だけで出せる範囲
            self.rng = {v: (self.lum(full(lo), full(lo), v).max(), self.lum(full(hi), full(hi), v).min()) for v in "AB"}
        else:          # 相手がどんな幅でも出せる範囲
            self.rng = {"A": (self.lum(full(umin), ub, "A").max(), self.lum(full(umax), ub, "A").min()),
                        "B": (self.lum(ub, full(umin), "B").max(), self.lum(ub, full(umax), "B").min())}
        mA = (self.A[1:] + self.A[:-1]) / 2                  # 面 i の中心（手前の像）
        mB = (self.B[1:] + self.B[:-1]) / 2
        ta = np.clip(self.sample("A", mA), 0, 1)
        tb = np.clip(self.sample("B", mB), 0, 1)
        LA = self.rng["A"][1] - (self.rng["A"][1] - self.rng["A"][0]) * ta
        LB = self.rng["B"][1] - (self.rng["B"][1] - self.rng["B"][0]) * tb
        uA = np.full_like(LA, (lo + hi) / 2)
        uB = uA.copy()
        for _ in range(40):
            t = (uA - uB) / (uA + uB)
            uA = np.clip((LA - INK_L) / (land_I(t, "A") - INK_L), lo, hi)
            uB = np.clip((LB - INK_L) / (land_I(t, "B") - INK_L), lo, hi)
        if wide:
            SL = self.p.get("SLOPE_U", 0.7)
            for _ in range(400):
                s = (uA + uB) / 2
                over = np.maximum((s[1:] + s[:-1]) / 2 - umax + 1e-4, 0)
                cut = np.zeros_like(s)
                cut[1:] = np.maximum(cut[1:], over)
                cut[:-1] = np.maximum(cut[:-1], over)
                cut[0] = np.maximum(cut[0], s[0] - umax + 1e-4)
                cut[-1] = np.maximum(cut[-1], s[-1] - umax + 1e-4)
                d = np.maximum(umin + 1e-4 - s, 0) - cut
                nA, nB = np.clip(uA + d, lo, hi), np.clip(uB + d, lo, hi)
                uA, uB = np.clip(nA + (uB + d - nB), lo, hi), np.clip(nB + (uA + d - nA), lo, hi)   # 端で動けない分は相手が受ける
                tt = (uA - uB) / (uA + uB)
                big = np.abs(tt) > SL
                s2, tt = (uA + uB) / 2, np.clip(tt, -SL, SL)
                uA, uB = np.where(big, s2 * (1 + tt), uA), np.where(big, s2 * (1 - tt), uB)
                if np.abs(d).max() < 1e-6 and not big.any():
                    break
        self.uA, self.uB, self.mA, self.mB = uA, uB, mA, mB
        self.target = {"A": LA, "B": LB}

    def build_edges(self):
        """溝の縁の空間曲線。溝 i の手前の縁 (Ylo, Zlo) と奥の縁 (Yhi, Zhi) [N, NX]。"""
        P = self.P
        gA, gB = self.uA * P, self.uB * P
        mA, mB = self.mA[:, None], self.mB[:, None]
        N = self.N
        eloA, ehiA, eloB, ehiB = (np.empty((N, self.NX)) for _ in range(4))
        ehiA[:-1], eloA[1:] = mA - gA / 2, mA + gA / 2
        ehiB[:-1], eloB[1:] = mB + gB / 2, mB - gB / 2          # 鏡の像では、溝の手前の縁が上に映る
        A, B = self.A[:, None], self.B[:, None]
        eloA[0], ehiA[-1] = 2 * A[0] - ehiA[0], 2 * A[-1] - eloA[-1]
        eloB[0], ehiB[-1] = 2 * B[0] - ehiB[0], 2 * B[-1] - eloB[-1]
        self.Z0 = self.p["BASE"] + self.p["GROOVE_D"] + 0.5          # 絵の周りの縁の高さ（板の底が 0）
        yz = lambda va, vb: ((va - vb) / (2 * SIN_E), self.Z0 + (va + vb) / (2 * COS_E))
        self.Ylo, self.Zlo = yz(eloA, eloB)
        self.Yhi, self.Zhi = yz(ehiA, ehiB)
        self.Zb = np.minimum(self.Zlo, self.Zhi) - self.p["GROOVE_D"]

    def validate(self):
        land = self.Ylo[1:] - self.Yhi[:-1]
        groove = self.Yhi - self.Ylo
        slope = (self.Zlo[1:] - self.Zhi[:-1]) / land
        rep = dict(
            lines=self.N, pitch_mm=self.P / SIN_E, u_range=(self.umin, self.umax),
            min_land_mm=float(land.min()), min_groove_mm=float(groove.min()), max_groove_mm=float(groove.max()),
            max_slope_y=float(np.abs(slope).max()),
            relief_mm=(float(min(self.Zlo.min(), self.Zhi.min()) - self.Z0), float(max(self.Zlo.max(), self.Zhi.max()) - self.Z0)),
            y_inside=bool(self.Ylo.min() > -self.HD and self.Yhi.max() < self.HD),
            size_mm=(self.W + 2 * self.p["BORDER"], 2 * (self.HD + self.p["BORDER"]), float(max(self.Zlo.max(), self.Zhi.max(), self.Z0))),
        )
        rep["ok"] = bool(rep["min_land_mm"] >= self.p["LAND_MIN"] - 1e-6 and rep["min_groove_mm"] >= self.p["GROOVE_W"] - 1e-6
                         and rep["max_slope_y"] < 0.8 and rep["y_inside"] and max(rep["size_mm"][:2]) <= 256)
        return rep

    # ---------------------------------------------------------- Bambu Studio の表示の再現
    def render(self, view, H=1200):
        """溝を墨で塗った板を Bambu Studio の照明・俯角 45° の正射影で描いた輝度 [H, NX]。B は鏡の中の向き。"""
        N = self.N
        y = np.stack([self.Ylo, self.Ylo, self.Yhi, self.Yhi], 1).reshape(4 * N, -1)
        z = np.stack([self.Zlo, self.Zb, self.Zb, self.Zhi], 1).reshape(4 * N, -1)
        ink = np.tile([True, True, True, False], N)[:-1]
        x = self.x
        if view == "B":
            y, z, ink, x = -y[::-1, ::-1], z[::-1, ::-1], ink[::-1], -x[::-1]
        v = y * SIN_E + (z - self.Z0) * COS_E
        zx = np.gradient(z, x, axis=1)
        dy, dz = np.diff(y, axis=0), np.diff(z, axis=0)
        sx = (zx[1:] + zx[:-1]) / 2
        n = np.stack([-sx * dy, -dz, dy], -1)
        n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-12
        d, sp = intensity(to_eye(n))
        lum = np.clip(np.where(ink[:, None, None], INK, WOOD) * d[..., None] + sp[..., None], 0, 1) @ LUM
        run = np.maximum.accumulate(v, axis=0)
        lo = np.maximum(v[:-1], np.vstack([v[:1], run[:-2]]))
        hi = v[1:]
        edges = np.linspace(-self.H / 2, self.H / 2, H + 1)
        img = np.zeros((H, v.shape[1]))
        for j in range(v.shape[1]):
            m = hi[:, j] > lo[:, j]
            a, b = lo[m, j], hi[m, j]
            cum = np.concatenate([[0], np.cumsum((b - a) * lum[m, j])])
            img[:, j] = np.diff(np.interp(edges, np.concatenate([a, b[-1:]]), cum)) / np.diff(edges)
        img = img[::-1]
        return img[:, ::-1] if view == "B" else img

    # ---------------------------------------------------------- 立体
    def mesh(self):
        """閉じた板の三角形メッシュ。戻り値 (頂点 [n, 3], 三角形 [m, 3], 溝の面か [m])。
        上面は列ごとの断面（縁 → 溝 → … → 縁）を左右につないだ高さ場。左右の端は絵の縁で Z0 に戻し、周りの縁へつなぐ。"""
        N, NX, Z0 = self.N, self.NX, self.Z0
        B = self.p["BORDER"]
        HD, W2 = self.HD, self.W / 2
        # 断面の点：周りの縁 (−HD−B)、絵の手前の縁 (−HD)、溝ごとに 4 点、絵の奥の縁 (HD)、周りの縁 (HD+B)
        Pn = 4 * N + 4
        Y = np.empty((NX, Pn))
        Z = np.empty((NX, Pn))
        Y[:, 0], Y[:, 1], Y[:, -2], Y[:, -1] = -HD - B, -HD, HD, HD + B
        Z[:, [0, 1, -2, -1]] = Z0
        Y[:, 2:-2:4], Z[:, 2:-2:4] = self.Ylo.T, self.Zlo.T
        Y[:, 3:-2:4], Z[:, 3:-2:4] = self.Ylo.T, self.Zb.T
        Y[:, 4:-2:4], Z[:, 4:-2:4] = self.Yhi.T, self.Zb.T
        Y[:, 5:-2:4], Z[:, 5:-2:4] = self.Yhi.T, self.Zhi.T
        # 左右に、縁の高さ Z0 の列を 2 つずつ足す（絵の端の 0.05 mm 外で溝を閉じ、周りの縁の外端へ）
        xs = np.concatenate([[-W2 - B, -W2 - 0.05], self.x, [W2 + 0.05, W2 + B]])
        Y = np.vstack([Y[:1], Y[:1], Y, Y[-1:], Y[-1:]])
        Z = np.vstack([np.full((2, Pn), Z0), Z, np.full((2, Pn), Z0)])
        C = len(xs)
        V = np.stack([np.repeat(xs, Pn), Y.ravel(), Z.ravel()], 1)
        idx = np.arange(C * Pn).reshape(C, Pn)
        seg = np.zeros(Pn - 1, bool)
        for k in range(3):
            seg[2 + k::4][:N] = True                      # 溝の前の壁・底・奥の壁
        # 軽くする：溝の縁の曲線（断面の点 p を左右につないだ折れ線）ごとに、TOL 以内で一直線に並ぶ点を間引く。
        # 隣り合う 2 本の折れ線の間の帯は、それぞれの残った点どうしを左右の順に結んで三角形にする
        # （折れ線は隣の 2 つの帯だけが共有するので、間引いても面の継ぎ目に食い違いは出ない）
        P3 = np.stack([np.broadcast_to(xs[:, None], (C, Pn)), Y, Z], -1)       # [C, Pn, 3]
        keeps = [simplify(P3[:, p], self.tol, fixed=(0, 1, 2, C - 3, C - 2, C - 1)) for p in range(Pn)]
        for g in range(N):                                # 溝 1 本の 4 本の折れ線は、残す列をそろえる（溝の壁を垂直に保つ）
            rows = range(2 + 4 * g, 6 + 4 * g)
            u = np.unique(np.concatenate([keeps[p] for p in rows]))
            for p in rows:
                keeps[p] = u
        # 面の帯（溝の壁・底以外）では、残った点の少ない側から長い三角形が扇状に張られ、相手の折れ線が波打つと
        # 上から見て裏返ることがある。裏返った三角形の範囲の列を、両側の折れ線に戻して張り直す
        group = np.arange(Pn)                             # 残す列をそろえる折れ線の組（溝ごとに 4 本）
        for g in range(N):
            group[2 + 4 * g:6 + 4 * g] = 2 + 4 * g
        for _ in range(50):
            tris, inks, bad = [], [], set()
            for p in range(Pn - 1):
                t = zipper(keeps[p], keeps[p + 1], idx[:, p], idx[:, p + 1])
                tris.append(t)
                inks.append(np.full(len(t), seg[p]))
                if not seg[p] and len(t):
                    a, b, c = V[t[:, 0]], V[t[:, 1]], V[t[:, 2]]
                    cz = (b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (b[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0])
                    for k in np.flatnonzero(cz < 0):
                        cols = t[k] // Pn
                        bad.add((p, int(cols.min()), int(cols.max())))
            if not bad:
                break
            add = {}
            for p, c0, c1 in bad:
                for q in (p, p + 1):
                    add.setdefault(group[q], []).append(np.arange(c0, c1 + 1))
            for gq, cols in add.items():
                u = np.union1d(keeps[gq], np.concatenate(cols))
                for q in np.flatnonzero(group == gq):
                    keeps[q] = u
        else:
            raise RuntimeError("裏返った三角形が残りました")
        T = np.concatenate(tris)
        INKF = np.concatenate(inks)
        # 同じ位置の頂点をまとめ、潰れた三角形を除く
        key = np.round(V * 1e5).astype(np.int64)
        _, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
        inv = inv.ravel()
        V = V[first]
        T = inv[T]
        keep = (T[:, 0] != T[:, 1]) & (T[:, 1] != T[:, 2]) & (T[:, 0] != T[:, 2])
        T, INKF = T[keep], INKF[keep]
        area = np.linalg.norm(np.cross(V[T[:, 1]] - V[T[:, 0]], V[T[:, 2]] - V[T[:, 0]]), axis=1)
        keep = area > 1e-9
        T, INKF = T[keep], INKF[keep]
        used = np.unique(T)                                   # 使われない頂点を除く
        remap = np.full(len(V), -1)
        remap[used] = np.arange(len(used))
        V, T = V[used], remap[T]
        # 上面の外周（1 枚の三角形にしか使われない辺）から、側面と底を作る
        e = np.concatenate([T[:, [0, 1]], T[:, [1, 2]], T[:, [2, 0]]])
        ek = e[:, 0] * len(V) + e[:, 1]
        rk = e[:, 1] * len(V) + e[:, 0]
        boundary = e[~np.isin(ek, rk)]
        nv = len(V)
        ub = np.unique(boundary)
        bmap = np.full(nv, -1)
        bmap[ub] = nv + np.arange(len(ub))
        Vb = V[ub].copy()
        Vb[:, 2] = 0.0
        ctr = nv + len(ub)
        V = np.vstack([V, Vb, [[0.0, 0.0, 0.0]]])
        u, w = boundary[:, 0], boundary[:, 1]
        side = np.concatenate([np.stack([w, u, bmap[u]], 1), np.stack([w, bmap[u], bmap[w]], 1)])
        bottom = np.stack([np.full(len(u), ctr), bmap[w], bmap[u]], 1)
        T = np.vstack([T, side, bottom])
        INKF = np.concatenate([INKF, np.zeros(len(side) + len(bottom), bool)])
        return V, T, INKF


def simplify(P, tol, fixed=()):
    """折れ線 P [n, 3] を Douglas-Peucker で間引き、残す点の番号（昇順）を返す。fixed の点は必ず残す。"""
    n = len(P)
    keep = np.zeros(n, bool)
    keep[list(fixed)] = True
    keep[[0, n - 1]] = True
    anchors = np.flatnonzero(keep)
    stack = list(zip(anchors[:-1], anchors[1:]))
    while stack:
        i, j = stack.pop()
        if j - i < 2:
            continue
        a, b = P[i], P[j]
        ab = b - a
        L2 = float(ab @ ab)
        q = P[i + 1:j] - a
        t = np.clip(q @ ab / L2, 0, 1) if L2 > 0 else np.zeros(len(q))
        d = np.linalg.norm(q - t[:, None] * ab, axis=1)
        k = int(np.argmax(d))
        if d[k] > tol:
            m = i + 1 + k
            keep[m] = True
            stack += [(i, m), (m, j)]
    return np.flatnonzero(keep)


def zipper(ka, kb, ia, ib):
    """左右に並んだ 2 本の折れ線（下 a・上 b、残った列の番号 ka・kb、頂点番号 ia・ib）の間の帯を三角形にする。
    向きは、上から見て反時計回り（格子の四角形 (a, a+1, b+1, b) を 2 つに割るのと同じ向き）。"""
    i = j = 0
    out = []
    while i < len(ka) - 1 or j < len(kb) - 1:
        if j == len(kb) - 1 or (i < len(ka) - 1 and ka[i + 1] <= kb[j + 1]):
            out.append((ia[ka[i]], ia[ka[i + 1]], ib[kb[j]]))
            i += 1
        else:
            out.append((ia[ka[i]], ib[kb[j + 1]], ib[kb[j]]))
            j += 1
    return np.array(out, np.int64).reshape(-1, 3)


def check_mesh(V, T):
    """閉じた立体か（どの辺もちょうど 2 枚、向きがそろう）と、体積・外形を調べる。"""
    e = np.concatenate([T[:, [0, 1]], T[:, [1, 2]], T[:, [2, 0]]])
    n = len(V)
    fwd = e[:, 0].astype(np.int64) * n + e[:, 1]
    uniq, cnt = np.unique(fwd, return_counts=True)
    rev = e[:, 1].astype(np.int64) * n + e[:, 0]
    paired = np.isin(fwd, rev)
    v0, v1, v2 = V[T[:, 0]], V[T[:, 1]], V[T[:, 2]]
    vol = float(np.einsum("ij,ij->i", v0, np.cross(v1, v2)).sum() / 6)
    nrm = np.cross(v1 - v0, v2 - v0)
    down = int(((nrm[:, 2] < -1e-9) & (np.minimum(np.minimum(v0[:, 2], v1[:, 2]), v2[:, 2]) > 1e-6)).sum())
    return dict(verts=len(V), tris=len(T), dup_directed_edges=int((cnt > 1).sum()), unpaired_edges=int((~paired).sum()),
                volume_cm3=vol / 1000, overhang_tris=down, bbox=(V.min(0).round(2).tolist(), V.max(0).round(2).tolist()))


def write_stl(path, V, T):
    v0, v1, v2 = V[T[:, 0]], V[T[:, 1]], V[T[:, 2]]
    n = np.cross(v1 - v0, v2 - v0)
    n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-20
    rec = np.zeros(len(T), dtype=[("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    rec["n"] = n
    rec["v"] = np.stack([v0, v1, v2], 1)
    with open(path, "wb") as f:
        f.write(b"painting-03 starry night / fujin raijin".ljust(80, b" "))
        f.write(struct.pack("<I", len(T)))
        f.write(rec.tobytes())


def write_painted_3mf(path, V, T, INKF, name):
    """溝の面を 2 番目のフィラメントで塗った 3MF（Bambu Studio の塗りの属性 paint_color="8"）。INKF が None なら塗りなし。
    Bambu Studio の自動配置は使わず、はじめから台の上の位置 (BED_X, BED_Y) に置く。"""
    V = V + np.array([BED_X, BED_Y, -V[:, 2].min()])
    if INKF is None:
        INKF = np.zeros(len(T), bool)
    vs = "".join(f'<vertex x="{a:.4f}" y="{b:.4f}" z="{c:.4f}"/>' for a, b, c in V.tolist())
    parts = []
    for (a, b, c), k in zip(T.tolist(), INKF.tolist()):
        parts.append(f'<triangle v1="{a}" v2="{b}" v3="{c}" paint_color="8"/>' if k else f'<triangle v1="{a}" v2="{b}" v3="{c}"/>')
    model = ('<?xml version="1.0" encoding="UTF-8"?>\n'
             '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" '
             'xmlns:slic3rpe="http://schemas.slic3r.org/3mf/2017/06">\n'
             f' <resources>\n  <object id="1" type="model" name="{name}">\n   <mesh>\n    <vertices>\n{vs}\n    </vertices>\n'
             f'    <triangles>\n{"".join(parts)}\n    </triangles>\n   </mesh>\n  </object>\n </resources>\n'
             ' <build>\n  <item objectid="1"/>\n </build>\n</model>\n')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Target="/3D/3dmodel.model" Id="rel0" '
                   'Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        z.writestr("3D/3dmodel.model", model)


def main():
    args = sys.argv[1:]

    def opt(flag, default=None):
        return args[args.index(flag) + 1] if flag in args else default
    prof_name = args[0] if args and not args[0].startswith("--") else "pair_raijin_n04"
    prof = dict(PROFILES[prof_name])
    if opt("--lines"):
        prof["N"] = int(opt("--lines"))
    if opt("--nx"):
        prof["NX"] = int(opt("--nx"))
    probe = opt("--probe", "")
    tag = opt("--tag") or f"p1s_{prof['NZ']}" + (f"_l{prof['N']}" if opt("--lines") else "") + (f"_probe{probe}" if probe else "")
    name = prof["NAME"]
    d = Design(prof, probe)
    rep = d.validate()
    print(f"[{tag}]")
    for k, v in rep.items():
        print(f"  {k}: {v}")
    rows = int(round(d.NX / d.aspect))
    vt = f"{name}_{tag}"                                    # 再現画像の名前
    a, b = d.render("A", rows), d.render("B", rows)
    out = os.path.join(HERE, "views")
    os.makedirs(out, exist_ok=True)
    gap = np.ones((a.shape[0], 16))
    write_png(os.path.join(out, f"sim_{vt}.png"), np.concatenate([a, gap, b], 1))
    s = 0.8 * d.P / d.H * rows                              # 線 1 本ぶんほどぼかす（少し離れて見た明暗）
    lo, hi = min(d.rng["A"][0], d.rng["B"][0]), max(d.rng["A"][1], d.rng["B"][1])
    ab, bb = [(blur(im, s, s) - lo) / (hi - lo) for im in (a, b)]
    write_png(os.path.join(out, f"sim_{vt}_blur.png"), np.concatenate([ab, gap, bb], 1)[::2, ::2])
    np.save(os.path.join(out, f"sim_{vt}.npy"), np.stack([a, b]).astype(np.float32))
    if "--no-mesh" in args:
        return
    V, T, INKF = d.mesh()
    chk = check_mesh(V, T)
    print("  mesh:", chk)
    os.makedirs(os.path.join(OUT_DIR, "print"), exist_ok=True)
    stem = os.path.join(OUT_DIR, f"{name}_{tag}")
    write_stl(stem + ".stl", V, T)
    write_painted_3mf(stem + "_painted.3mf", V, T, INKF, f"{name}_{tag}")
    write_painted_3mf(os.path.join(OUT_DIR, "print", f"{name}_{tag}_plain.3mf"), V, T, None, f"{name}_{tag}")
    print("書き出し:", stem + ".stl", stem + "_painted.3mf")


if __name__ == "__main__":
    main()
