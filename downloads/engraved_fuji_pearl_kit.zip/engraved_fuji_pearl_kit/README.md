# 生成アート錯視：赤富士と少女　3D プリント用データ一式（平らな版・長辺 15 cm・0.4 mm ノズル）

著者：渡部匡己、杉永友美、渡辺英治（基礎生物学研究所）
公開ページ：https://masaki425.github.io/engraved-fuji-pearl/

表面が平らな板の立体錯視である。手前から見ると葛飾北斎「凱風快晴」、後ろに立てた鏡の中ではフェルメール「真珠の耳飾りの少女」が見える。
家庭用の熱溶解 3D プリンター **Bambu Lab P1S** の **標準の 0.4 mm ノズル** で造形することを前提に、寸法・溝の幅・溝の間の面の幅を定めている。
作者の環境では、この一式の STL を P1S により単色で造形し、墨入れなしで、手前に赤富士が、鏡の中に少女が見えることを確認した。

## 同梱ファイル

| ファイル | 内容 |
|---|---|
| `stl/engraved_fuji_pearl_flat_p1s_n04_s15.stl` | STL |
| `bambu_studio/engraved_fuji_pearl_flat_p1s_n04_s15_project.3mf` | Bambu Studio 用プロジェクト（P1S 0.4 nozzle・0.12mm Fine・Arachne・外側ブリム 3 mm の設定入り） |
| `scripts/` | 設計・スライス・検証・Blender での組み立てのスクリプトと元の絵（作り直す場合にのみ使う） |

| | |
|---|---|
| 板の大きさ | 110 × 150 × 5.3 mm |
| 絵の部分 | 手前からも鏡の中でも 96 mm 角の正方形に見える |
| 溝 | 71 本・等間隔（平面上 1.92 mm）・深さ 1.0 mm |
| 最も細い溝 / 溝の間の面 | 0.50 mm / 0.50 mm |
| 上面の起伏 | ±0.25 mm 程度 |

- 単位はすべて mm である。**スライサーでの拡大・縮小は行わないこと。** 拡大・縮小すると溝の幅がノズルに合わなくなり、錯視も崩れる。
- STL は一体の閉じた立体である。下向きの面はなく、サポートは不要である。

## Bambu Lab P1S の設定（Bambu Studio）

プロジェクトを開くと、下表の設定が入った状態になる。「スライス」を押せば、そのまま造形できる。

| 項目 | 設定 |
|---|---|
| プリンター | Bambu Lab P1S 0.4 nozzle |
| 工程（プリセット） | 0.12mm Fine @BBL X1C |
| フィラメント | Bambu PLA Matte（ベージュ・白など明るい色） |
| 積層ピッチ | 0.12 mm（溝の深さが約 8 層） |
| 壁生成 | Arachne（プリセットの既定は Classic） |
| インフィル | 15 % |
| サポート | 不要 |
| ブリム | 外側 3 mm（厚さ 5 mm の薄板の反りを抑える） |
| 造形時間・材料（見積もり） | 約 1 時間 40 分・52 g |

- 彫った面を上にして平らに置く。
- P1S 用の公式プリセットでスライスし、G-code の押し出し経路を設計の断面と重ねて検証した。溝のある深さの全層において、溝の間の面の欠けは 0、ふさがった溝も 0 であった。
- AMS による 2 色造形は推奨しない。溝だけを黒く造形しようとしても、溝の間の面は押し出し 1 本分の幅しかない。G-code を色ごとに分けて調べると、面の内部はほぼ黒で造形され、地色は最上層の 1 層のみとなった。単色で造形すること。

## 仕上げ

墨入れなしでも、溝の陰影によって絵が見える（作者の試作は墨入れなしである）。
線をより明瞭にする場合は、溝に黒のアクリル絵の具（または墨）を流し込み、乾く前に固く絞った布で表面を拭き取る。
塗りは地色と溝の中の黒のみであり、どちらから見ても同じである。2 つの絵の違いは、彫りの形状だけから生じる。

## 展示方法

- 作品の奥に鏡を立てる。手前の実物に赤富士が、鏡に映った像に少女が見える。
- 俯角 45° かそれよりやや低い位置から、真正面（左右 ±15° 以内）に見下ろす。俯角 52° 以上では、もう一方の絵の輪郭が透けてくる。
- 上方から、やわらかい光を手前と奥に均等に当てる。スポットライトや横からの強い光は避ける。
- 板を 180° 回転させると、手前と鏡の中の絵が入れ替わる（どちらの絵も左右反転して見える）。

## スクリプトによる再生成

`scripts/` には、設計からスライス・検証・Blender での再現までのスクリプトをまとめている（STL を造形するだけであれば使わない）。
コマンドは、この一式の最上位のフォルダ（`engraved_fuji_pearl_kit/`）で実行する。numpy と Blender 5.2 を用いる。

| ファイル | 役割 |
|---|---|
| `design_flat.py` | この作品の設定。絵（赤富士・少女）、大きさ、明暗の作り方を決め、`design.py` で設計して STL・3MF・再現画像を書き出す |
| `design.py` | 設計の本体。溝の間の面の見かけの幅を解き、溝の縁の空間曲線・検証・見え方の再現・メッシュ・書き出しを行う（絵や大きさは `design_flat.py` から受け取る） |
| `slice_flat.py` / `slice_p1s.py` | Bambu Studio のコマンドラインで P1S 用にスライスする（前者がこの作品用の入口、後者が設定の本体） |
| `check_flat.py` / `check_lands.py` | スライス結果の G-code を設計の断面と重ね、面の欠けと溝のふさがりを数える（同上） |
| `build_blend_flat.py` / `build_blend.py` | Blender に実寸の板・鏡・照明・カメラを置いて再現する（同上） |
| `source/` | 元の絵と、それを配列に変換する `convert_images.py` |

`*_flat.py` がこの作品の入口であり、同じ名前の相手（`design.py` など）が共通の本体である。本体は同じ方式で作った別の作品と共用しているため、説明文にはその作品の名前が出てくる。

1. 元の絵の変換（Blender で実行する。`source/` に `.npy` が作られる）
   ```
   /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup --python scripts/source/convert_images.py
   ```
2. 設計・STL（Blender 同梱の Python で実行する。`scripts/` に STL・3MF が、`scripts/views/` に再現画像が作られる）
   ```
   /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 scripts/design_flat.py flat_n04_s15
   ```
3. スライス（Bambu Studio が必要。`scripts/print/` に作られる）
   ```
   python3 scripts/slice_flat.py flat_n04_s15 --project
   ```
4. G-code の照合（3 の後に実行する）
   ```
   /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 scripts/check_flat.py flat_n04_s15
   ```
5. Blender での再現
   ```
   /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup --python scripts/build_blend_flat.py -- --profile flat_n04_s15 --render
   ```

明暗の作り方、溝の設計、陰影の打ち消しについては、`design.py` の冒頭に説明がある。コードの設計には Claude Code（モデルは Claude Opus 5.5）を用いた。

## クレジットと利用条件

- 着想：杉原厚吉「変身立体」。
- 元の絵（パブリックドメイン、Wikimedia Commons）：葛飾北斎「冨嶽三十六景 凱風快晴」、ヨハネス・フェルメール「真珠の耳飾りの少女」。
- 溝の設計と造形データは、本作品のために新たに作成したものである。
