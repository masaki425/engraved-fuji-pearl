"""再現した Bambu Studio の表示で、もう一方の絵の透けを測る（design.py の --probe 版と比べる）。
  python3 leak_sim.py <tag> [溝の本数]   … views/sim_<tag>.npy と sim_<tag>_probe{A,B}.npy を使う（design.py の --probe で作る）
  例：leak_sim.py pair_starry_raijin_p1s_n04 / leak_sim.py pair_rhone_fujin_p1s_n02"""
import os
import sys

import numpy as np

import design as D

tag = sys.argv[1]
load = lambda t: np.load(os.path.join(D.HERE, "views", f"sim_{t}.npy"))
base = load(tag)
rows = base.shape[1]
lines = int(sys.argv[2]) if len(sys.argv) > 2 else D.PROFILES["pair_raijin_" + ("n02" if "n02" in tag else "n04")]["N"]
s = 0.8 * rows / lines
st = lambda im: D.blur(im, s, s)[30:-30, 30:-30]             # 線 1 本ぶんほどぼかした像（縁を除く）
# 透け：本物の相手の絵がある像と、相手の絵を一様にした像（--probe）の差。相手の絵がそのまま映り込んだ分だけ残る。
# （片方を一様にした像のばらつきだけを見る方法では、UVIEW で幅が押し合う所の透けを捉えられない）
for v, name, other in ((0, "手前の像に透ける鏡の中の絵", "B"), (1, "鏡の中の像に透ける手前の絵", "A")):
    b = st(base[v])
    lk = b - st(load(tag + "_probe" + other)[v])
    lo, hi = np.percentile(b, [2, 98])
    print(f"{name}: 透け {lk.std() / b.std() * 100:.1f} %（像のばらつき {b.std():.4f}、明暗の比 {hi / lo:.2f}）")
