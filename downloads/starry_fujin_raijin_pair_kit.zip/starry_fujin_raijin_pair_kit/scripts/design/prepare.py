"""2 枚組の元の絵を切り抜き、設計で使う配列（.npy、sRGB 0..1、上の行が絵の上）にする。縦横比はどれも ASPECT（1.27）。

  星月夜（sn_pair）          ：上下を 4 画素ずつ切るだけ（ほぼ全体）
  ローヌ川の星月夜（rhone）   ：左右を 15 画素ずつ切るだけ
  雷神・風神（raijin・fujin）：風神雷神図屏風の 1 隻ずつ。金地の端から 4 画素内側で、下の金地を少し詰める

  cd painting-03/design/source && sips -s format bmp starry_night.jpg --out starry_night.bmp \\
      && sips -s format bmp starry_night_rhone.jpg --out starry_night_rhone.bmp \\
      && sips -s format bmp fujin_raijin.png --out fujin_raijin.bmp        # サンドボックスの外で
  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/design/prepare.py

出力：source/sn_pair.npy・rhone.npy・raijin.npy・fujin.npy と、確認用の source/crops_pair.png
      （左の列が左に置く 1 枚＝星月夜と雷神、右の列が右に置く 1 枚＝ローヌ川の星月夜と風神）
"""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source")
ROWS = 1000             # 配列の縦の画素数


def load_bmp(path):
    """24/32 ビット無圧縮 BMP → [h, w, 3]（0..1 の sRGB、上の行が絵の上）。"""
    b = open(path, "rb").read()
    off = int.from_bytes(b[10:14], "little")
    w = int.from_bytes(b[18:22], "little", signed=True)
    h = int.from_bytes(b[22:26], "little", signed=True)
    step = int.from_bytes(b[28:30], "little") // 8
    row = (w * step + 3) // 4 * 4
    a = np.frombuffer(b, np.uint8, count=row * abs(h), offset=off).reshape(abs(h), row)[:, :w * step]
    a = a.reshape(abs(h), w, step)[..., [2, 1, 0]].astype(np.float32) / 255
    return a[::-1] if h > 0 else a


def resize(img, rows, cols):
    """面積平均で縮める（縦横それぞれ、区間に入る画素の平均）。"""
    def axis(a, n, ax):
        m = a.shape[ax]
        e = np.linspace(0, m, n + 1)
        c = np.concatenate([np.zeros_like(np.take(a, [0], ax)), np.cumsum(a, ax)], ax)
        lo, hi = np.floor(e[:-1]).astype(int), np.floor(e[1:]).astype(int)
        hi = np.maximum(hi, lo + 1)
        return (np.take(c, hi, ax) - np.take(c, lo, ax)) / (hi - lo).reshape([-1 if i == ax else 1 for i in range(a.ndim)])
    return axis(axis(img, rows, 0), cols, 1).astype(np.float32)


def screens():
    """風神雷神図屏風（2249 × 1028、左隻：雷神、右隻：風神）。扇の継ぎ目（暗い縦線）を、両側の画素から埋めたもの。"""
    img = load_bmp(os.path.join(SRC, "fujin_raijin.bmp"))
    for c0, c1 in ((556, 566), (1683, 1692)):
        f = np.linspace(0, 1, c1 - c0 + 1)[None, :, None]
        img[:, c0:c1 + 1] = img[:, c0:c0 + 1] * (1 - f) + img[:, c1:c1 + 1] * f
    return img


ASPECT = 1.27           # 額の横 / 縦（見かけ。4 枚の絵がどれも 1.26〜1.29。design.py の ASPECT と同じ）


def main():
    """4 枚の絵を切り抜く。屏風は 1 隻ずつ、金地の端（左隻 x 55〜1066、右隻 x 1184〜2192、上端 y 56）から 4 画素内側で、
    縦横比 1.27 になるよう下の金地を詰めて切り抜く。二神とも、元の屏風と同じ広い金地の余白の中に置かれる。"""
    sc = screens()
    out = {}
    for name, (x0, x1) in (("raijin", (59, 1062)), ("fujin", (1188, 2188))):
        h = int(round((x1 - x0) / ASPECT))
        out[name] = sc[60:60 + h, x0:x1]
    sn = load_bmp(os.path.join(SRC, "starry_night.bmp"))               # 1920 × 1520 → 上下を 4 画素ずつ
    h = int(round(sn.shape[1] / ASPECT))
    y0 = (sn.shape[0] - h) // 2
    out["sn_pair"] = sn[y0:y0 + h]
    rh = load_bmp(os.path.join(SRC, "starry_night_rhone.bmp"))         # 1920 × 1488 → 左右を 15 画素ずつ
    w = int(round(rh.shape[0] * ASPECT))
    x0 = (rh.shape[1] - w) // 2
    out["rhone"] = rh[:, x0:x0 + w]
    cols = int(round(ROWS * ASPECT))
    import design as D
    tiles = {}
    for k, im in out.items():
        a = resize(im, ROWS, cols)
        np.save(os.path.join(SRC, k + ".npy"), a)
        tiles[k] = a[::2, ::2]
    g = np.ones((tiles["fujin"].shape[0], 10, 3), np.float32)
    top = np.concatenate([tiles["sn_pair"], g, tiles["rhone"]], 1)          # 列ごとに 1 枚（左：星月夜 ⇄ 雷神、右：ローヌ川 ⇄ 風神）
    bot = np.concatenate([tiles["raijin"], g, tiles["fujin"]], 1)
    D.write_png(os.path.join(SRC, "crops_pair.png"), np.concatenate([top, np.ones((10, top.shape[1], 3), np.float32), bot], 0))
    print("書き出し:", {k: v.shape for k, v in out.items()})


if __name__ == "__main__":
    main()
