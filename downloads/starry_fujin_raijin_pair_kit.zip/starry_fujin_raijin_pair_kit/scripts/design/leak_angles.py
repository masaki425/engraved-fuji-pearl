"""実物の部屋の照明（天井からのやわらかい光・溝に墨）で、俯角ごとの透けを測る。打ち消しの照明を Bambu Studio 向けと実物向けで比べる。

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/design/leak_angles.py [版 ...]
  版：pair_raijin_n04・pair_fujin_n04・pair_raijin_n02・pair_fujin_n02（省略時は n04 の 2 つ）
出力：views/leak_angles_<名前>_<ノズル>.txt と views/angles_<名前>_<ノズル>.png
  （画像は、上の段が実物向けの打ち消し（今の版）、下の段が Bambu Studio 向け（2026-09-29 までの版）。
    左から俯角 35・45・55・65°、各組の左が手前、右が鏡の中）
透けは、相手の絵を一様にした版（--probe と同じ）との差を、像の明暗のばらつきで割ったもの。再現の断面・照明は
painting-01/flat/ridge_coupons.py（render・leak）と同じ。
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "painting-01", "flat"))
import design as D           # noqa: E402
import ridge_coupons as RC   # noqa: E402

ANGLES = [30, 35, 40, 45, 50, 55, 60, 65]
SHOW = (35, 45, 55, 65)


def profile(d):
    """平らな版の断面 (Y, Z, 次の区間が墨か) [NX, 4N + 4]。"""
    N, NX, B = d.N, d.NX, d.p["BORDER"]
    Y = np.empty((NX, 4 * N + 4))
    Z = np.full((NX, 4 * N + 4), d.Z0)
    Y[:, 0], Y[:, 1], Y[:, -2], Y[:, -1] = -d.HD - B, -d.HD, d.HD, d.HD + B
    Y[:, 2::4][:, :N], Z[:, 2::4][:, :N] = d.Ylo.T, d.Zlo.T
    Y[:, 3::4][:, :N], Z[:, 3::4][:, :N] = d.Ylo.T, d.Zb.T
    Y[:, 4::4][:, :N], Z[:, 4::4][:, :N] = d.Yhi.T, d.Zb.T
    Y[:, 5::4][:, :N], Z[:, 5::4][:, :N] = d.Yhi.T, d.Zhi.T
    ink = np.zeros(4 * N + 3, bool)
    for k in range(3):
        ink[2 + k::4][:N] = True
    return Y, Z, ink


def measure(prof):
    d = D.Design(prof)
    Y, Z, ink = profile(d)
    prA, prB = profile(D.Design(prof, "A")), profile(D.Design(prof, "B"))
    rows = int(round(d.NX / d.aspect))
    sb = 0.8 * rows / d.N
    res, show = [], []
    for th in ANGLES:
        a = RC.render(Y, Z, ink, "A", th, rows, d.HD)
        b = RC.render(Y, Z, ink, "B", th, rows, d.HD)
        la, ca = RC.leak(a, RC.render(*prB, "A", th, rows, d.HD), d.N)
        lb, cb = RC.leak(b, RC.render(*prA, "B", th, rows, d.HD), d.N)
        res.append((th, la, ca, lb, cb))
        if th in SHOW:
            show.append((D.blur(a, sb, sb), D.blur(b, sb, sb)))
    parts = []
    for a, b in show:
        parts += [a, np.full((a.shape[0], 4), 0.5), b, np.ones((a.shape[0], 10))]
    return res, np.clip(np.concatenate(parts[:-1], 1) / RC.WOOD_L, 0, 1)


def main(key):
    prof = D.PROFILES[key]
    name = f"{prof['NAME']}_{prof['NZ']}"
    out = {}
    for light in ("room", "bambu"):
        out[light] = measure(dict(prof, LIGHT=light))
    lines = [f"{name}  部屋のやわらかい照明・溝に墨で見たときの透け（もう一方の絵の強さ / 明暗の比）",
             "俯角   実物向けの打ち消し（今の版）：手前 / 鏡          Bambu Studio 向け（09-29 まで）：手前 / 鏡"]
    for (th, la, ca, lb, cb), (_, la2, ca2, lb2, cb2) in zip(out["room"][0], out["bambu"][0]):
        lines.append(f" {th:>3}°  {la * 100:5.1f} % / {ca:.2f}  {lb * 100:5.1f} % / {cb:.2f}"
                     f"          {la2 * 100:5.1f} % / {ca2:.2f}  {lb2 * 100:5.1f} % / {cb2:.2f}")
    txt = "\n".join(lines)
    print(txt)
    os.makedirs(os.path.join(HERE, "views"), exist_ok=True)
    open(os.path.join(HERE, "views", f"leak_angles_{name}.txt"), "w").write(txt + "\n")
    img = np.concatenate([out["room"][1], np.ones((10, out["room"][1].shape[1])), out["bambu"][1]], 0)
    D.write_png(os.path.join(HERE, "views", f"angles_{name}.png"), img[::2, ::2])


if __name__ == "__main__":
    for k in sys.argv[1:] or ["pair_raijin_n04", "pair_fujin_n04"]:
        main(k)
