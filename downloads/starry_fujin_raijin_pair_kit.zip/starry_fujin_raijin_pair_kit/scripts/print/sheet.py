"""print/bambu_views/ の画像を、行ごとに「正面 | 背面（鏡の向き）」で並べる。PNG は sips で BMP にして読む（サンドボックスの外で）。
  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/print/sheet.py <出力.png> <名前> ...
"""
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "design"))
import design as D  # noqa: E402
import prepare as P  # noqa: E402


def load(png, crop=(95, 420, 40, 472)):
    bmp = png[:-4] + ".bmp"
    subprocess.run(["sips", "-s", "format", "bmp", png, "--out", bmp], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    im = P.load_bmp(bmp)
    os.remove(bmp)
    r0, r1, c0, c1 = crop
    return im[r0:r1, c0:c1]


out, names = sys.argv[1], sys.argv[2:]
rows = []
for n in names:
    vd = os.path.join(os.path.dirname(HERE), "pair", "print", "bambu_views")
    f, b = (load(os.path.join(vd, f"{n}_{s}.png")) for s in ("front", "back_mirrored"))
    rows.append(np.concatenate([f, np.ones((f.shape[0], 10, 3), np.float32), b], 1))
gap = np.ones((10, rows[0].shape[1], 3), np.float32)
D.write_png(out, np.concatenate(sum([[r, gap] for r in rows], [])[:-1], 0))
print("書き出し:", out)
