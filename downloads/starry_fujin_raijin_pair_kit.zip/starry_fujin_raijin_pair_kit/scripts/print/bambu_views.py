"""溝を黒で塗った確認用 3MF を Bambu Studio 自身に描かせ、正面（手前の像）と背面（鏡の中の像）の画像を作る。
ユーザーが Bambu Studio の画面で見るのと同じ描画で確かめるためのもの（painting-02/private/print/bambu_views.py と同じ手順）。

  python3 painting-03/print/bambu_views.py <*_painted.3mf> ...   # サンドボックスの外で
  例：painting-03/pair/pair_starry_raijin_p1s_n04_painted.3mf、確かめる用は pair/print/probe/…_probeA_painted.3mf

出力：pair/print/bambu_views/<名前>_front.png・_back_mirrored.png（背面の像を左右反転して、鏡に映した向きにしたもの）
      pair/print/<名前>_project.3mf（地の色と墨の 2 色を割り当てた Bambu Studio のプロジェクト。開くとそのまま塗りが見える。
      確かめる用（_probe）は作らない）
"""
import os
import re
import shutil
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BAMBU = "/Applications/BambuStudio.app/Contents/MacOS/BambuStudio"
PDIR = os.path.join(ROOT, "pair", "print")
OUT = os.path.join(PDIR, "bambu_views")



def presets(stem):
    """ノズルに合った AMS 2 色のプリセット（slice_p1s.py --presets-only n04_ams n02_ams が書き出したもの）。
    プライムタワーなし（板が台いっぱいで置けない）。開いたプロジェクトは、そのまま 2 色でスライスできる。"""
    d = os.path.join(HERE, "presets_n02_ams" if "_n02" in stem else "presets_n04_ams")
    return f"{d}/machine.json;{d}/process.json", f"{d}/filament_1.json;{d}/filament_2.json"


def run(cmd, log):
    with open(log, "w") as f:
        r = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        sys.exit(f"失敗（{r.returncode}）: {' '.join(cmd[:3])} … ログ {log}")


def rotate_180(src, dst):
    """3MF のモデルを、台の中央 (128, 128) を通る鉛直軸のまわりに 180° 回す（背面から見た像を、正面のカメラで描くため）。"""
    z = zipfile.ZipFile(src)
    m = z.read("3D/3dmodel.model").decode()
    m = re.sub(r'<vertex x="(-?[\d.]+)" y="(-?[\d.]+)"',
               lambda g: f'<vertex x="{256 - float(g.group(1)):.4f}" y="{256 - float(g.group(2)):.4f}"', m)
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as o:
        for n in z.namelist():
            o.writestr(n, m if n == "3D/3dmodel.model" else z.read(n))


def views(painted):
    stem = os.path.basename(painted)[:-len("_painted.3mf")]
    os.makedirs(OUT, exist_ok=True)
    tmp = os.path.join(OUT, "tmp_" + stem)
    os.makedirs(tmp, exist_ok=True)
    rotate_180(painted, os.path.join(tmp, "back.3mf"))
    for side, src in (("front", painted), ("back", os.path.join(tmp, "back.3mf"))):
        proj = os.path.join(tmp, side + "_project.3mf")
        settings, filaments = presets(stem)
        run([BAMBU, "--orient", "0", "--arrange", "0", "--load-settings", settings, "--load-filaments", filaments,
             "--export-3mf", proj, src], os.path.join(tmp, side + "_project.log"))
        if side == "front" and "_probe" not in stem:
            shutil.copy(proj, os.path.join(PDIR, stem + "_project.3mf"))
        d = os.path.join(tmp, side)
        os.makedirs(d, exist_ok=True)
        run([BAMBU, "--export-png", "0", "--camera-view", "1", "--outputdir", d, proj], os.path.join(tmp, side + "_png.log"))
    front = os.path.join(OUT, stem + "_front.png")
    back = os.path.join(OUT, stem + "_back_mirrored.png")
    shutil.copy(os.path.join(tmp, "front", "plate_1_1.png"), front)
    shutil.copy(os.path.join(tmp, "back", "plate_1_1.png"), back)
    subprocess.run(["sips", "-f", "horizontal", back], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    shutil.rmtree(tmp)
    print("書き出し:", front, back, flush=True)


if __name__ == "__main__":
    for p in sys.argv[1:]:
        views(os.path.abspath(p))
