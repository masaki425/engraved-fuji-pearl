"""試し刷り：「星月夜 ⇄ 雷神」の一部（70 mm 幅・溝 36 本）を、濃淡の範囲を変えた 3 通りで切り出し、1 枚の台に並べる。

  1（左）  ：前の版     手前・鏡それぞれの面の見かけの幅 26〜74 %（透けが最も少ない）
  2（中央）：18〜82 %  透けは 1 と同じ程度で、濃淡が約 2 割強い（本番に採用）
  3（右）  ：12〜88 %  さらに濃淡が強いが、もう一方の絵がわずかに透ける（再現で 3.5 %）

板の手前右の縁に、番号の数だけ小さな突起（2 × 2 × 0.6 mm）を付ける（手前の向きの目印も兼ねる）。
切り出す場所は、手前の像（糸杉と渦の左側）と鏡の中の像（雷神の体と太鼓の輪）の両方に形がはっきりある所を、
再現画像の明るさのばらつきが両方とも大きくなる窓として選んだ（溝 27〜63 番、x = −85〜−15 mm）。

  /Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13 painting-03/print/test_coupons.py
  python3 painting-03/print/test_coupons.py --slice            # スライス（サンドボックスの外で）
出力：pair/test_print/ に STL・塗った 3MF（Bambu Studio で開く用）・スライス済み 3MF・再現画像
"""
import copy
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "pair", "test_print")
VARIANTS = [("1_now", None), ("2_u18", (0.18, 0.82)), ("3_u12", (0.12, 0.88))]
G0, NG = 27, 36                 # 切り出す溝（番号 G0 から NG 本）
X0, X1 = -85.0, -15.0           # 切り出す左右の範囲 [mm]
CX = [45.0, 128.0, 211.0]       # 台の上の中心 x（板 76 mm・すき間 7 mm。3 枚で x 7〜249 mm。左手前の使えない区画は y 28 mm 以下なのでかからない）
CY = 128.0
BORDER = 3.0


def crop(d):
    """設計 d の一部を切り出した、同じ形の小さな設計（mesh() がそのまま使える）。"""
    import numpy as np
    c = copy.copy(d)
    j = (d.x >= X0) & (d.x <= X1)
    g = slice(G0, G0 + NG)
    yf = (d.Yhi[G0 - 1, j].max() + d.Ylo[G0, j].min()) / 2          # 手前の切り口：直前の面の中ほど
    yb = (d.Yhi[G0 + NG - 1, j].max() + d.Ylo[G0 + NG, j].min()) / 2  # 奥の切り口：直後の面の中ほど
    assert d.Yhi[G0 - 1, j].max() < yf < d.Ylo[G0, j].min()
    assert d.Yhi[G0 + NG - 1, j].max() < yb < d.Ylo[G0 + NG, j].min()
    yc = (yf + yb) / 2
    c.x = d.x[j] - (X0 + X1) / 2
    c.NX, c.N, c.W = int(j.sum()), NG, X1 - X0
    c.HD = (yb - yf) / 2
    c.Ylo, c.Yhi = d.Ylo[g][:, j] - yc, d.Yhi[g][:, j] - yc
    c.Zlo, c.Zhi, c.Zb = d.Zlo[g][:, j], d.Zhi[g][:, j], d.Zb[g][:, j]
    c.p = dict(d.p, BORDER=BORDER)
    return c


def dots(n, c, top):
    """板の手前右の縁の上に、n 個の小さな直方体の突起（閉じた三角形メッシュ）。"""
    import numpy as np
    V, T = [], []
    for k in range(n):
        x0 = c.W / 2 + BORDER - 2.5 - k * 3.5 - 2.0
        y0 = -c.HD - BORDER + 0.5
        b = len(V)
        for z in (top, top + 0.6):
            V += [(x0, y0, z), (x0 + 2, y0, z), (x0 + 2, y0 + 2, z), (x0, y0 + 2, z)]
        T += [(b, b + 2, b + 1), (b, b + 3, b + 2), (b + 4, b + 5, b + 6), (b + 4, b + 6, b + 7)]
        for i in range(4):
            a, bb = i, (i + 1) % 4
            T += [(b + a, b + bb, b + 4 + bb), (b + a, b + 4 + bb, b + 4 + a)]
    return np.array(V, float), np.array(T, int)


def build():
    import numpy as np
    sys.path.insert(0, os.path.join(ROOT, "design"))
    import design as D
    os.makedirs(OUT, exist_ok=True)
    allV, allT, allI = [], [], []
    sims = []
    for k, (name, uv) in enumerate(VARIANTS):
        prof = {k: v for k, v in D.PROFILES["pair_raijin_n04"].items() if k != "UVIEW"}   # 1 は範囲を固定する前の方式
        if uv:
            prof["UVIEW"] = uv
        d = D.Design(prof)
        c = crop(d)
        c.H = 2 * c.HD * D.SIN_E                              # 切り出した範囲の見かけの高さ（再現画像用）
        V, T, I = c.mesh()
        chk = D.check_mesh(V, T)
        print(name, "溝", c.N, "本、板", round(c.W + 2 * BORDER, 1), "×", round(2 * (c.HD + BORDER), 1), "mm、", chk["tris"], "三角形、",
              "閉じた立体" if chk["unpaired_edges"] == 0 and chk["dup_directed_edges"] == 0 else "閉じていない", flush=True)
        dv, dt = dots(k + 1, c, d.Z0)
        V2 = np.vstack([V, dv])
        T2 = np.vstack([T, dt + len(V)])
        I2 = np.concatenate([I, np.zeros(len(dt), bool)])
        D.write_stl(os.path.join(OUT, f"coupon_{name}.stl"), V2, T2)
        allV.append(V2 + np.array([CX[k] - D.BED_X, CY - D.BED_Y, 0]))
        allT.append(T2)
        allI.append(I2)
        r = int(round(c.NX * c.H / c.W))
        sims.append(np.concatenate([c.render("A", r), np.ones((r, 8)), c.render("B", r)], 1))
    off = np.cumsum([0] + [len(v) for v in allV[:-1]])
    V = np.vstack(allV)
    T = np.vstack([t + o for t, o in zip(allT, off)])
    I = np.concatenate(allI)
    D.write_painted_3mf(os.path.join(OUT, "coupons_painted.3mf"), V, T, I, "coupons")
    D.write_painted_3mf(os.path.join(OUT, "coupons_plain.3mf"), V, T, None, "coupons")
    img = np.concatenate(sum([[s, np.ones((8, s.shape[1]))] for s in sims], [])[:-1], 0)
    D.write_png(os.path.join(OUT, "coupons_sim.png"), (img - img.min()) / (img.max() - img.min()))
    print("書き出し:", OUT)


def slice_all():
    sys.argv = [sys.argv[0]]
    sys.path.insert(0, HERE)
    import slice_p1s as S
    S.VARIANTS["coupons_n04"] = S.nozzle_variant("n04", False, model="../pair/test_print/coupons_plain.3mf",
                                                 out="../pair/test_print/coupons_n04_P1S.3mf")
    S.VARIANTS["coupons_n04_ams"] = S.nozzle_variant("n04", True, model="../pair/test_print/coupons_painted.3mf",
                                                     out="../pair/test_print/coupons_n04_ams_P1S.3mf")
    for k in ("coupons_n04", "coupons_n04_ams"):
        S.slice_variant(k)


if __name__ == "__main__":
    slice_all() if "--slice" in sys.argv else build()
