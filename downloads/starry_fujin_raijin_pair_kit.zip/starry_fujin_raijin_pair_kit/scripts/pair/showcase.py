"""2 枚組の展示写真：左に「星月夜 ⇄ 雷神」、右に「ローヌ川の星月夜 ⇄ 風神」を並べ、奥に大きな鏡を 1 枚立てる。
手前から俯角 45° で見ると、手前に 2 つの星月夜、鏡の中に雷神（左）と風神（右）が並ぶ（鏡は奥行きだけを反転するので左右は入れ替わらない）。

  /Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup --python painting-03/pair/showcase.py -- [--quick]
出力：pair/showcase_pair.blend、pair/showcase_mirror.png（鏡を入れた展示写真）・pair/showcase_mirror_only.png（鏡の中だけを拡大）
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "design"))
import design as DS  # noqa: E402

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
QUICK = "--quick" in args
SIN_E, COS_E = DS.SIN_E, DS.COS_E
LEFT = DS.Design(DS.PROFILES["pair_raijin_n04"])      # 星月夜 ⇄ 雷神
RIGHT = DS.Design(DS.PROFILES["pair_fujin_n04"])      # ローヌ川の星月夜 ⇄ 風神
SC = LEFT.H / 162.0                          # シーンの縮尺（すき間・カメラ・鏡・照明は、絵の高さ 162 mm の板に合わせて決めた値を縮める）
GAP = 30.0 * SC                              # 2 枚の板の間のすき間 [mm]
CAM_DIST, MIRROR_EXTRA = 3000.0 * SC, 340.0 * SC
Z0 = LEFT.Z0
BW = LEFT.W + 2 * LEFT.p["BORDER"]                    # 板 1 枚の横幅
TARGET = Vector((0, 0, Z0))


def lin(h):
    h = h.lstrip("#")
    f = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return tuple(f(int(h[i:i + 2], 16) / 255) for i in (0, 2, 4))


def plain(name, rgb, rough=0.6, metallic=0.0):
    m = bpy.data.materials.new(name)
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metallic
    return m


def panel(name, d, x0, mats, coll):
    V, T, INKF = d.mesh()
    V = V + np.array([x0, 0, 0])
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(V))
    me.vertices.foreach_set("co", V.astype(np.float32).ravel())
    me.loops.add(3 * len(T))
    me.loops.foreach_set("vertex_index", T.astype(np.int32).ravel())
    me.polygons.add(len(T))
    me.polygons.foreach_set("loop_start", np.arange(0, 3 * len(T), 3, dtype=np.int32))
    me.update(calc_edges=True)
    for m in mats:
        me.materials.append(m)
    me.polygons.foreach_set("material_index", INKF.astype(np.int32))
    me.polygons.foreach_set("use_smooth", np.zeros(len(T), bool))   # フラットシェーディング（なめらか表示だと溝の縁の傾きが面ににじむ）
    ob = bpy.data.objects.new(name, me)
    coll.objects.link(ob)
    return ob


def view_dir(s):
    return Vector((0, s * COS_E, SIN_E))


def look_at(ob, t):
    ob.rotation_euler = (t - ob.location).to_track_quat("-Z", "Y").to_euler()


def camera(name, loc, target, lens, coll):
    cam = bpy.data.cameras.new(name)
    cam.lens = lens
    cam.clip_start, cam.clip_end = 5, 20000
    ob = bpy.data.objects.new(name, cam)
    coll.objects.link(ob)
    ob.location = loc
    look_at(ob, target)
    return ob


def mirror(coll):
    """実カメラ C と、奥から俯角 45° で見る仮想カメラ C' の垂直二等分面に鏡を置く（painting-01 と同じ）。"""
    C = TARGET + view_dir(-1) * CAM_DIST
    Cp = TARGET + view_dir(+1) * (CAM_DIST + MIRROR_EXTRA)
    M, nrm = (C + Cp) / 2, (C - Cp).normalized()
    up = Vector((0, -nrm.z, nrm.y))
    up = up if up.z > 0 else -up
    w, h, fw = 2 * BW + GAP + 260 * SC, 560.0 * SC, 14.0 * SC
    s = (fw - M.z) / up.z
    center = M + up * s + up * (h / 2)
    right = Vector((1, 0, 0))
    for name, ww, hh, off, mat in (("MirrorFrame", w + 2 * fw, h + 2 * fw, -2.0, plain("FrameBlack", (0.03, 0.03, 0.03), 0.4)),
                                    ("Mirror", w, h, 0.0, plain("MirrorSilver", (0.80, 0.88, 0.86), 0.0, 1.0))):
        me = bpy.data.meshes.new(name)
        vs = [center + nrm * off + right * sx * ww / 2 + up * sy * hh / 2 for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        me.from_pydata([tuple(v) for v in vs], [], [(0, 1, 2, 3)])
        me.update()
        if me.polygons[0].normal.dot(nrm) < 0:
            me.flip_normals()
        me.materials.append(mat)
        ob = bpy.data.objects.new(name, me)
        coll.objects.link(ob)
    return C


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.unit_settings.system = "METRIC"
    sc.unit_settings.scale_length = 0.001
    sc.render.engine = "CYCLES"
    sc.cycles.samples = 32 if QUICK else 192
    sc.cycles.use_denoising = True
    sc.view_settings.view_transform = "Standard"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "METAL"
        prefs.get_devices()
        for dev in prefs.devices:
            dev.use = True
        sc.cycles.device = "GPU"
    except Exception as exc:
        print("GPU unavailable:", exc)
    coll = sc.collection
    mats = [plain("Ji", lin("#e6d3b1"), 0.75), plain("Sumi", lin("#15120f"), 0.9)]
    xo = (BW + GAP) / 2
    panel("Left_StarryNight_Raijin", LEFT, -xo, mats, coll)
    panel("Right_Rhone_Fujin", RIGHT, +xo, mats, coll)
    world = bpy.data.worlds.new("World")
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.85, 0.84, 0.81, 1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.1
    sc.world = world
    for name, sy in (("Light_Front", -1), ("Light_Back", 1)):
        L = bpy.data.objects.new(name, bpy.data.lights.new(name, "AREA"))
        L.data.shape = "DISK"
        L.data.size = 2200 * SC
        L.data.energy = 1.2e6 * SC ** 2
        L.location = (0, sy * 750 * SC, 950 * SC)
        look_at(L, Vector((0, 0, Z0 * 0.5)))
        coll.objects.link(L)
    top = bpy.data.objects.new("Light_Top", bpy.data.lights.new("Light_Top", "AREA"))
    top.data.size = 1600 * SC
    top.data.energy = 0.7e6 * SC ** 2
    top.location = (0, 0, 1400 * SC)
    coll.objects.link(top)
    bpy.ops.mesh.primitive_plane_add(size=8000, location=(0, 0, 0))
    bpy.context.active_object.data.materials.append(plain("Table", lin("#d6cfc1"), 0.85))
    C = mirror(coll)
    upA = Vector((0, SIN_E, COS_E))
    show = camera("Cam_Showcase", C, TARGET + upA * (MIRROR_EXTRA * 0.5), 112, coll)
    # 鏡の中だけ：同じ位置から、鏡に映った 2 枚（奥の仮想の位置）へ向ける
    virt = TARGET + upA * MIRROR_EXTRA
    only = camera("Cam_MirrorOnly", C, virt, 200, coll)
    sc.camera = show
    blend = os.path.join(HERE, "showcase_pair.blend")
    bpy.ops.wm.save_as_mainfile(filepath=blend)
    base = 900 if QUICK else 2400
    for cam, fn, (rx, ry) in ((show, "showcase_mirror.png", (int(base * 0.8), base)),
                              (only, "showcase_mirror_only.png", (base, int(base * 0.5)))):
        sc.camera = cam
        sc.render.resolution_x, sc.render.resolution_y = rx, ry
        sc.render.filepath = os.path.join(HERE, fn)
        bpy.ops.render.render(write_still=True)
        print("rendered", sc.render.filepath, flush=True)
    sc.camera = show
    bpy.ops.wm.save_as_mainfile(filepath=blend)


main()
